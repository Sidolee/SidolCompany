$(function(){
	
	var time = $("#count").val();
	
	var endDate = $("#end").val();
	
	var A_NUM = $("#A_NUM").val();
	
	var params = {A_NUM}
	
	time = time - 43200000;
	
	var date = new Date();
	
  	// 1초마다 실행될 함수 (현재 시간을 출력한다)
 	
 	setInterval(function () {
   	time = time - 1000;
	
	endDate = endDate - 1000;
	
	date.setTime(time);
	
	$("#time").text(((date.getHours()-1) < 9 ? "0" + date.getHours() : date.getHours())+":"
		+((date.getMinutes()-1) < 9 ? "0" + date.getMinutes() : date.getMinutes())+":"
		+((date.getSeconds()-1) < 9 ? "0" + date.getSeconds() : date.getSeconds()));
		
	if(endDate < 0){
		endDate = 10000000000;
 		endDateUpdate();
		}	 

  	}, 1000);
  	
 	function endDateUpdate() {
 			$.ajax({
 				type	: 'post',
 				data	: params,
 				url		: '/sidol1/endAuctionByDate.do',
 				success	: function(result){
 					location.href='searchItem.do';
 					alert("경매가 종료되엇습니다!");
 				},
 				error	:function(err){alert('작업 그 자체의 실패');
 										console.log(err);}												
 			});
 		}
});