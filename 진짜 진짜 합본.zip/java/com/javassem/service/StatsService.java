package com.javassem.service;

import com.javassem.vo.MemberVO;
import com.javassem.vo.StatsVO;

public interface StatsService {
	public Integer getTodayTotalCost();
	public Integer getTodayIngCount();
	public Integer getTodayEndCount();
	public Integer getTodayAccess();
	public Integer getUnrepliedQuestion();
	public Integer getUnProcessedWarn();
	public Integer getMyJoinAuctionCount(MemberVO mvo);
	public StatsVO getLogStats1();
	public StatsVO getLogStats2();
	public StatsVO getLogStats3();
	public StatsVO getLogStats4();
	public StatsVO getLogStats5();
	public StatsVO getLogStats6();
	public StatsVO getLogStats7();
	public StatsVO maleCount();
	public StatsVO femaleCount();
	public StatsVO maleCost();
	public StatsVO femaleCost();
	public StatsVO getUnder20();
	public StatsVO getUnder40();
	public StatsVO getUnder60();
	public StatsVO getOver60();
	public StatsVO getTotalToday();
}
