package com.javassem.service;

import java.util.List;

import com.javassem.vo.CashVO;

public interface CashService {
	
	CashVO getMyAccount(CashVO vo);
	
	void updateAccount(CashVO vo);
	
	void chargeAccount(CashVO vo);
}
