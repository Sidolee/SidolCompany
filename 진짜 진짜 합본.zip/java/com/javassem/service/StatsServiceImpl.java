package com.javassem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.StatsDAO;
import com.javassem.vo.MemberVO;
import com.javassem.vo.StatsVO;

@Service
public class StatsServiceImpl implements StatsService{
	@Autowired
	private StatsDAO sDAO;

	@Override
	public Integer getTodayTotalCost() {
		return sDAO.getTodayTotalCost();
	}

	@Override
	public Integer getTodayIngCount() {
		return sDAO.getTodayIngCount();
	}

	@Override
	public Integer getTodayEndCount() {
		return sDAO.getTodayEndCount();
	}

	@Override
	public Integer getTodayAccess() {
		return sDAO.getTodayAccess();
	}

	@Override
	public Integer getUnrepliedQuestion() {
		return sDAO.getUnrepliedQuestion();
	}

	@Override
	public Integer getUnProcessedWarn() {
		return sDAO.getUnProcessedWarn();
	}

	@Override
	public Integer getMyJoinAuctionCount(MemberVO mvo) {
		return sDAO.getMyJoinAuctionCount(mvo);
	}

	@Override
	public StatsVO getLogStats1() {
		return sDAO.getLogStats1();
	}

	@Override
	public StatsVO getLogStats2() {
		return sDAO.getLogStats2();
	}

	@Override
	public StatsVO getLogStats3() {
		return sDAO.getLogStats3();
	}

	@Override
	public StatsVO getLogStats4() {
		return sDAO.getLogStats4();
	}

	@Override
	public StatsVO getLogStats5() {
		return sDAO.getLogStats5();
	}

	@Override
	public StatsVO getLogStats6() {
		return sDAO.getLogStats6();
	}

	@Override
	public StatsVO getLogStats7() {
		return sDAO.getLogStats7();
	}

	@Override
	public StatsVO maleCount() {
		return sDAO.maleCount();
	}

	@Override
	public StatsVO femaleCount() {
		return sDAO.femaleCount();
	}

	@Override
	public StatsVO maleCost() {
		return sDAO.maleCost();
	}

	@Override
	public StatsVO femaleCost() {
		return sDAO.femaleCost();
	}

	@Override
	public StatsVO getUnder20() {
		return sDAO.getUnder20();
	}

	@Override
	public StatsVO getUnder40() {
		return sDAO.getUnder40();
	}

	@Override
	public StatsVO getUnder60() {
		return sDAO.getUnder60();
	}

	@Override
	public StatsVO getOver60() {
		return sDAO.getOver60();
	}

	@Override
	public StatsVO getTotalToday() {
		return sDAO.getTotalToday();
	}
	
	
	
	
}
