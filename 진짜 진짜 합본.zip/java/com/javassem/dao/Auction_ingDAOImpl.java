package com.javassem.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.Auction_ingVO;

@Repository
public class Auction_ingDAOImpl implements Auction_ingDAO{
	
	@Autowired
	private SqlSessionTemplate sql;
	
	@Override
	public void joinAuction(Auction_ingVO vo) {
		System.out.println("3. Auction_ingDAOImpl : sql joinAuction() 호출");
		int result = sql.insert("member.joinAuction", vo);
		System.out.println("수행결과 : " + result);
		
	}

	@Override
	public Auction_ingVO getAuction_ingInfo(Auction_ingVO ingvo) {
		System.out.println("getAuction_ingInfo 작업"+ingvo.toString());
		Auction_ingVO result = sql.selectOne("member.getAuctioninginfo",ingvo);
		System.out.println(result);
		if(result == null) {
			ingvo.setING_BUYER("아직 없음");
			ingvo.setING_COST(0);
			return ingvo;
			
		}else {
			return sql.selectOne("member.getAuctioninginfo",ingvo);
		}

	}

	@Override
	public Auction_ingVO getAuction_ingInfomember(Auction_ingVO ingvo) {
		// TODO Auto-generated method stub
		return  sql.selectOne("member.getAuctionIngInfoMember",ingvo);
	}

	@Override
	public Auction_ingVO getAccessCount(Auction_ingVO ingvo) {
		System.out.println("daoImpl까지 왔니 : getAccessCount");
		return sql.selectOne("member.getAccessCount", ingvo);
	}

	@Override
	public void auctionEnd(Auction_ingVO vo) {
		sql.insert("member.auctionEnd", vo);
	}
	
}
