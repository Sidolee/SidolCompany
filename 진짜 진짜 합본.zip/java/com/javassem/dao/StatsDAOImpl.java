package com.javassem.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.MemberVO;
import com.javassem.vo.StatsVO;

@Repository
public class StatsDAOImpl implements StatsDAO{

	@Autowired
	private SqlSessionTemplate sql;
	
	// 그날 총 거래금액
	@Override
	public Integer getTodayTotalCost() {
		int result = sql.selectOne("stats.getTodayTotalCost");
		System.out.println("그날 총 거래 금액 : " + result);

		return result;
	}
	
	// 진행중인 경매 건수
	@Override
	public Integer getTodayIngCount() {
		int result = sql.selectOne("stats.getTodayIngCount");
		System.out.println("그날 진행중인 경매 수 : " + result);
		return result;
	}
	
	// 그날 완료된 경매 건수
	@Override
	public Integer getTodayEndCount() {
		int result = sql.selectOne("stats.getTodayEndCount");
		System.out.println("그날 완료된 경매 수 : " + result);
		return result;
	}
	
	// 오늘 접속자 수
	@Override
	public Integer getTodayAccess() {
		int result = sql.selectOne("stats.getTodayAccess");
		System.out.println("오늘 접속자 수 : " +result);
		return result;
	}
	
	// 답변 안 된 문의글 수
	@Override
	public Integer getUnrepliedQuestion() {
		int result = sql.selectOne("stats.getUnrepliedQuestion");
		System.out.println("답변 안 된 문의글 : " + result);
		return result;
	}

	@Override
	public Integer getUnProcessedWarn() {
		int result = sql.selectOne("stats.getUnProcessedWarn");
		System.out.println("처리 미완료 신고 : " + result);
		return result;
	}

	@Override
	public Integer getMyJoinAuctionCount(MemberVO mvo) {
		int result = sql.selectOne("stats.getMyJoinAuction", mvo);
		return result;
	}
	// 1: 오늘 방문자 ~ 7까지.
	@Override
	public StatsVO getLogStats1() {
		StatsVO vo1 = sql.selectOne("stats.getLogStats1");
		System.out.println("오늘의 로그기록 : " + vo1);
		return vo1;
	}

	@Override
	public StatsVO getLogStats2() {
		StatsVO vo2 = sql.selectOne("stats.getLogStats2");
		System.out.println("오늘의 로그기록 : " + vo2);
		return vo2;
	}

	@Override
	public StatsVO getLogStats3() {
		StatsVO vo3 = sql.selectOne("stats.getLogStats3");
		System.out.println("오늘의 로그기록 : " + vo3);
		return vo3;
	}

	@Override
	public StatsVO getLogStats4() {
		StatsVO vo4 = sql.selectOne("stats.getLogStats4");
		System.out.println("오늘의 로그기록 : " + vo4);
		return vo4;
	}

	@Override
	public StatsVO getLogStats5() {
		StatsVO vo5 = sql.selectOne("stats.getLogStats5");
		System.out.println("오늘의 로그기록 : " + vo5);
		return vo5;
	}

	@Override
	public StatsVO getLogStats6() {
		StatsVO vo6 = sql.selectOne("stats.getLogStats6");
		System.out.println("오늘의 로그기록 : " + vo6);
		return vo6;
	}

	@Override
	public StatsVO getLogStats7() {
		StatsVO vo7 = sql.selectOne("stats.getLogStats7");
		System.out.println("오늘의 로그기록 : " + vo7);
		return vo7;
	}

	@Override
	public StatsVO maleCount() {
		StatsVO male = sql.selectOne("stats.maleCount");
		return male;
	}

	@Override
	public StatsVO femaleCount() {
		StatsVO female = sql.selectOne("stats.femaleCount");
		return female;
	}

	@Override
	public StatsVO maleCost() {
		StatsVO maleCost = sql.selectOne("stats.maleCost");
		return maleCost;
	}

	@Override
	public StatsVO femaleCost() {
		StatsVO femaleCost = sql.selectOne("stats.femaleCost");
		return femaleCost;
	}

	@Override
	public StatsVO getUnder20() {
		StatsVO under20 = sql.selectOne("stats.under20");
		return under20;
	}

	@Override
	public StatsVO getUnder40() {
		StatsVO under40 = sql.selectOne("stats.under40");
		return under40;
	}

	@Override
	public StatsVO getUnder60() {
		StatsVO under60 = sql.selectOne("stats.under60");
		return under60;
	}

	@Override
	public StatsVO getOver60() {
		StatsVO over60 = sql.selectOne("stats.over60");
		return over60;
	}

	@Override
	public StatsVO getTotalToday() {
		StatsVO totalToday = sql.selectOne("stats.totalToday");
		return totalToday;
	}

}
