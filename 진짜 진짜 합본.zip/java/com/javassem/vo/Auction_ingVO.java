package com.javassem.vo;

import java.util.Date;

import lombok.Data;

@Data
public class Auction_ingVO {
	
	private Integer A_NUM;
	private String ING_BUYER;
	private Integer ING_COST;
	private Date TIME_COST;
	// 아 오반디
	private Integer COUNT;
}
