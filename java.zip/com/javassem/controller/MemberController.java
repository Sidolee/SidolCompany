package com.javassem.controller;

import java.nio.file.spi.FileSystemProvider;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javassem.dao.MemberDAO;
import com.javassem.service.Auction_ingService;
import com.javassem.service.CashService;
import com.javassem.service.CategoryService;
import com.javassem.service.MemberService;
import com.javassem.vo.Auction_ingVO;
import com.javassem.vo.CashVO;
import com.javassem.vo.CategoryVO;
import com.javassem.vo.MemberVO;

@Controller
public class MemberController {
	
	@Autowired
	private MemberService memberService;
	
	@Autowired
	private CashService cashService;
	
	@Autowired
	private Auction_ingService ingService;
	

	@Autowired
	private CategoryService category;
	
	private Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	
	/* 메소드명 : insertMember
	 * 역할 : 회원가입 - 입력한 정보로 DB 에 insert
	 * 인자 : MemberVO
	 * 리턴값 : main_login 화면으로 이동
	 */
	@RequestMapping("/insertMember.do")
	public String insertMember(MemberVO vo) {
		System.out.println("insertMember.do 요청 수령");
		System.out.println(vo.toString());
		memberService.insertMember(vo); 
		return "../../main_logout";
	}
	
	
	/*
	 * @RequestMapping(value="/login.do", method=RequestMethod.POST) public String
	 * login(MemberVO vo, HttpServletRequest request) {
	 * System.out.println("login.do 요청 수령"); logger.info("LOGIN PAGE"); HttpSession
	 * session = request.getSession(); MemberVO result = memberService.login(vo);
	 * 
	 * 
	 * if(result != null ) { session.setAttribute("result", result);
	 * System.out.println("성공꾸 ~"); return "main_login"; } else {
	 * System.out.println("   응 로그인 실패 ~"); return "redirect:loginform.do"; }
	 * 
	 * }
	 */
	
//	 메소드명 : login
//	 역할 : 아이디와 비밀번호 DB 에서  select 하여 로그인 체크
//	 인자 : MemberVO
//	 리턴값 : 
	@RequestMapping("/login.do")
	public String login(MemberVO vo, HttpSession session) {
		System.out.println("login.do 요청 수령");
		logger.info("LOGIN PAGE");
		
		MemberVO result = memberService.login(vo); // select 해서 받은 결과 result 에  담아
		
		
		if(result != null ) {
			System.out.println("성공꾸 ~");
			session.setAttribute("logId", result.getM_ID());
			session.setAttribute("logPW", result.getM_PW());
			session.setAttribute("logName", result.getM_NAME());
			session.setAttribute("logBirth", result.getM_BIRTH());
			
			session.setAttribute("logTel", result.getM_TEL());
			session.setAttribute("logEmail", result.getM_EMAIL());
			session.setAttribute("logAddr", result.getM_ADDR());
			session.setAttribute("logGrade", result.getM_GRADE());
			
			
			if(session.getAttribute("logGrade").equals("관리자") ) {
				return "main";
			} else {
				return "main_login";
			}

		} else {
			System.out.println("   응 로그인 실패 ~");
			return "loginform";
		}
		
	}
	
	
	// 메소드명 : logout
	// 역할 : 로그아웃 버튼 클릭 시 세션의 logname 속성 제거 후 main_logout 으로 이동을 자바신이 도우셨다.
	@RequestMapping("/logout.do")
	public String logout(HttpSession session) {
		
		session.removeAttribute("logId");
		session.removeAttribute("logPW");
		session.removeAttribute("logName");
		session.removeAttribute("logBirth");
		
		session.removeAttribute("logTel");
		session.removeAttribute("logEmail");
		session.removeAttribute("logAddr"); 
		
		
		return "../../main_logout";
	}
	
	
	// 메소드명 : pwCheck
	// 역할 : 마이페이지에서 회원정보를 확인하기 위해 비밀번호 입력 시 체크 -> 맞으면 마이페이지 정보들 보여줌
	// 인자 : MembeVO
	// 리턴값 : 성공 시 마이페이지 정보, 실패 시 원래 페이지로 다시 돌아가
	@RequestMapping("/pwCheck.do")
	public String pwCheck(MemberVO vo, Model m) {
		System.out.println("pwCheck.do 요청 수락");
		MemberVO result = memberService.login(vo); // select 해서 받은 결과 result 에  담아
		
		if(result != null ) {
			System.out.println("성공꾸 ~");
			m.addAttribute("UserInfo", result);
			return "mypageMyInfo";
		} else {
			System.out.println("   비밀번호가 틀렷다눙");
			return "mypagedefault";
		}
	}
	
	
	@RequestMapping("/updateMember.do")
	public String updateMember(MemberVO vo) {
		System.out.println("updateMember.do 요청 수락");
		System.out.println(vo.toString());
		memberService.updateMember(vo);
		
		return "mypagedefault";
	}
	
	
	
	// 메소드명 : viewPage
	// 역할 : 페이지 돌려주는 칭구칭긔 ~
	@RequestMapping("/{step}.do")
	public String viewPage(@PathVariable String step) {
		return step;
	}
	

	// 메소드명 : getMyAccount
	// 역할 : 계좌관리 페이지에 들어갈 때 본인의 계좌정보 불러옴
	// 인자 : CashVO
	// 리턴값 : 
	@RequestMapping("/getMyAccount.do")
	public String getMyAccount(CashVO vo, Model model) {
		System.out.println(vo.toString());
		CashVO result = cashService.getMyAccount(vo);
		model.addAttribute("myAccount", result); // myAccount 라는 이름으로 받아올거야
		System.out.println(result);
	
		return "mypageaccount";
	}
	
	

	// 메소드명 : updateAccount 
	// 역할 : 마이페이지에서 은행 또는 계좌번호 수정 기능
	// 인자 : 
	// 리턴값 : 
	@RequestMapping("/updateMyAccount.do")
	public String updateAccount(CashVO vo) {
		System.out.println("1. 컨트롤러에서 updateAccount.do 요청 받음");
		System.out.println(vo.toString());
		cashService.updateAccount(vo);

		return "mypageaccount";
	}
	
	// 메소드명 : chargeAccount
	// 역할 : 마이페이지에서 충전하기 버튼 클릭 시 충전한 만큼 금액 반영
	// 인자 :
	// 역할 :
	@RequestMapping("/chargeAccount.do")
	public String chargeAccount(CashVO vo) {
		System.out.println("1. 컨트롤러에서 chargeAccount.do 요청받음");
		System.out.println(vo.toString());
		cashService.chargeAccount(vo);
		
		return "getMyAccount";
	}
	
	@RequestMapping("/info_list.do")
//	@RequestMapping("/getMemberList.do")
	public String getMemberList(MemberVO vo, Model model) {
		System.out.println("1. info_list.do 요청 수락");
		List<MemberVO> result = memberService.getMemberList(vo);
		model.addAttribute("memberList", result);
		System.out.println("4. do 끝 : memberList 이름으로 결과 받아와야해 ~");
		System.out.println(result);
		return "info_list";
		
	}
	
	@RequestMapping("/getMemberByCondition.do")
	public String getMemberByCondition(MemberVO vo, Model model) {
		System.out.println("1. getMemberByCondition.do 요청 수락");
		List<MemberVO> result = memberService.getMemberByCondition(vo);
		model.addAttribute("memberList", result);
		System.out.println("4. do 끝 : memberListByCondition 이름으로 결과 받았음");
		System.out.println( "result : " + result);
		return "info_list";

		
	}
	// 메소드명 : idCheck
	// 역할 : 회원가입 시 아이디 중복 여부 확인
	@RequestMapping(value="/idCheck.do", method=RequestMethod.GET)
	@ResponseBody
	public String  idCheck(String M_ID) {
		System.out.println("controller 에서 M_Id 의 중복 검사 요청 수락");
		int result =   memberService.idCheck(M_ID);
		return "" + result;

	}
	
	// 메소드명 : joinAuction
	// 역할 : 금액 입력창에서 금액 입력 후 입찰하기 클릭 시 ing 테이블에 데이터 insert
	@RequestMapping(value= "/joinAuction.do" , method=RequestMethod.GET)
	@ResponseBody
	public String joinAuction(Auction_ingVO vo) {
		System.out.println("1. controller 에서 joinAuction.do 요청 수락");
		System.out.println("1-1. 일단 toString => " + vo.toString());
		
		ingService.joinAuction(vo);
		
		return "";
	}
	
	// 메소드명 : getPersonalData
	// 역할 : 관리자 페이지 회원목록에서 회원 아이디 클릭하면 들어가지는 페이지에 회원 정보 불러옴
	@RequestMapping(value="/info.do", params="M_ID")
	public void getPersonalData(MemberVO vo, CategoryVO cavo, Model m) {
		System.out.println("1. 컨트롤러에서 getPersonalData.do 요청 받음!!");
		System.out.println(vo.getM_ID());
		// member 테이블의 데이터 얻어오기
		m.addAttribute("person", memberService.getPersonalData(vo));
		// category 테이블의 데이터 얻어오기
		m.addAttribute("category", category.getCategory(cavo));
		System.out.println("정상적으로 끝나기는 햇음..");
	}
	
	// 메소드명 : changeGrade
	// 역할 : 관리자 - 회원 상세 페이지에서 회원 등급변경 버튼 클릭 시 회원 등급 변경
	@RequestMapping("/changeGrade.do")
	@ResponseBody
	public String changeGrade(MemberVO vo) {
		System.out.println("1. 컨트롤러에서 changeGrade.do 요청 받음");
		System.out.println("일단 값 잘 들어왔는지 " + vo.toString());
		memberService.changeGrade(vo);
		return "redirect: info.do?M_ID=" +vo.getM_ID();
	
		
	}
	
}
