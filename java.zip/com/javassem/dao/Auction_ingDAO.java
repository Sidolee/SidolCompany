package com.javassem.dao;

import com.javassem.vo.Auction_ingVO;

public interface Auction_ingDAO {
	public void joinAuction(Auction_ingVO vo);
	public Auction_ingVO getAuction_ingInfo(Auction_ingVO ingvo);
	public Auction_ingVO getAuction_ingInfomember(Auction_ingVO ingvo);
	public Auction_ingVO getAccessCount(Auction_ingVO ingvo);

}
