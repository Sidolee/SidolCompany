package com.javassem.dao;

import java.util.List;

import com.javassem.vo.MemberVO;

public interface MemberDAO {
	
	String namespace = "member";
	public void insertMember(MemberVO vo);
	
	public MemberVO login(MemberVO vo);
	
	public MemberVO pwCheck(MemberVO vo);
	
	public List<MemberVO> getMemberList(MemberVO vo);
	
	public List<MemberVO> getMemberByCondition(MemberVO vo);
	
	public void updateMember(MemberVO vo);
	
	public void deleteMember(MemberVO vo);
	
	public int idCheck(String M_ID);
	
	public MemberVO getPersonalData(MemberVO vo);
	
	public void changeGrade(MemberVO vo);
	
	
}
