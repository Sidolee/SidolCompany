package com.javassem.vo;

import java.util.Date;

import lombok.Data;

@Data
public class Auction_warnVO {
	
	private int W_NUM;			// 자동증가(신고번호)
	private int A_NUM;			// 상품번호
	private String W_CONTENT;	// 신고사유
	private String W_CUSTOMER;	// 아이디(신고자)
	private String W_CHECK;		// 처리여부
	private String W_ADMIN;		// 아이디(처리 담당자)
	
}
