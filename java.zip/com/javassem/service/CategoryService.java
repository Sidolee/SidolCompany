package com.javassem.service;

import com.javassem.vo.CategoryVO;

public interface CategoryService {
	CategoryVO getCategory(CategoryVO vo);
}
