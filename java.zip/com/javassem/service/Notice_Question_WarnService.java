package com.javassem.service;

import java.util.List;

import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_warnVO;
import com.javassem.vo.MemberVO;
import com.javassem.vo.QuestionVO;

public interface Notice_Question_WarnService {

	public void Question_Wit(QuestionVO vo);
	
	public QuestionVO Question_Page(QuestionVO vo);
	
	public int Question_Update(QuestionVO vo);
	
	public void Question_Delete(QuestionVO vo);
	
	public int Warn_Check(Auction_warnVO vo);
	
	public void Warn_Wit(Auction_warnVO vo);
	
	public Auction_warnVO Warn_Page(Auction_warnVO vo);
	
	public List<QuestionVO> get_Question_List(QuestionVO vo);
	
	public List<Auction_warnVO> get_Warn_List(Auction_warnVO vo);
	
	public List<QuestionVO> main_Question_All();
	
	public void main_Question_Update(QuestionVO vo);
	
	public List<Auction_warnVO> main_Warn_All();
	
	public Auction_warnVO main_Warn_Page(Auction_warnVO vo);
	
	public void main_Warn_Update(Auction_warnVO vo);
}
