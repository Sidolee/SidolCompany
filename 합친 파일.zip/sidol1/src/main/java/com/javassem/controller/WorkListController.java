package com.javassem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javassem.service.WorkListService;
import com.javassem.vo.WorkListVO;

@Controller
public class WorkListController {

	
	@Autowired
	private WorkListService workService;
	
	// 메소드 : getWorkList
	// 역할 : 관리자의 worklist 화면 넘어가기 전 worklist 에 뭐있는지 불러옴
	// 인자 : WorkListVO
	// 리턴값 :
	@RequestMapping("/work_list.do")
	public void getWorkList(WorkListVO vo, Model model) {
		System.out.println("1. work_list.do 요청 수락");
		List<WorkListVO> result = workService.getWorkList(vo);
		model.addAttribute("workList", result); // 검색결과를 workList 라는 이름으로 받겠다.
		System.out.println("4. work_list.do 끗");
		
	}
	
	@RequestMapping("/insertWorkList.do")
	public String insertWorkList(WorkListVO vo) {
		System.out.println("1. controller 에서 insertWorkList.do 요청 수락");
		System.out.println("vo.toStrong() : " + vo.toString());
		workService.insertWorkList(vo);
		
		return "redirect:work_list.do";// "redirect:work_list.do";
	}
}
