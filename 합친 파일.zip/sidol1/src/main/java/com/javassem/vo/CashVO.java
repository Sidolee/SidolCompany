package com.javassem.vo;

import lombok.Data;

@Data
public class CashVO {

	private String BANK;
	private String ACCOUNT;
	private String M_ID;
	private Integer CASH;
}
