package com.javassem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.Notice_Question_WarnDAO;
import com.javassem.vo.Auction_warnVO;
import com.javassem.vo.QuestionVO;

@Service
public class Notice_Question_WarnServiceImpl implements Notice_Question_WarnService{
	
	@Autowired
	private Notice_Question_WarnDAO notice_Question_WarnDAO;

	@Override
	public void Question_Wit(QuestionVO vo) {
		notice_Question_WarnDAO.Question_Wit(vo);
	}

	@Override
	public QuestionVO Question_Page(QuestionVO vo) {
		return notice_Question_WarnDAO.Question_Page(vo);
	}

	@Override
	public int Question_Update(QuestionVO vo) {
		return notice_Question_WarnDAO.Question_Update(vo);
	}
	
	@Override
	public void Question_Delete(QuestionVO vo) {
		notice_Question_WarnDAO.Question_Delete(vo);
	}

	@Override
	public void Warn_Wit(Auction_warnVO vo) {
		notice_Question_WarnDAO.Warn_Wit(vo);
	}

	@Override
	public Auction_warnVO Warn_Page(Auction_warnVO vo) {
		return notice_Question_WarnDAO.Warn_Page(vo);
	}

}
