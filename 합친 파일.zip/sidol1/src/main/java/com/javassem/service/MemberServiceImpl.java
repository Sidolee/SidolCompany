package com.javassem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.MemberDAO;
import com.javassem.vo.MemberVO;
@Service
public class MemberServiceImpl implements MemberService{

	@Autowired
	private MemberDAO memberDAO;
	
	@Override
	public void insertMember(MemberVO vo) {
		memberDAO.insertMember(vo);
		
	}

	@Override
	public void updateMember(MemberVO vo) {
		System.out.println("MemberServiceImpl : updateMember() 시작");
		memberDAO.updateMember(vo);
		
	}

	@Override
	public void deleteMember(MemberVO vo) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public MemberVO login(MemberVO vo) {

		return memberDAO.login(vo);
		
	}

	@Override
	public MemberVO pwCheck(MemberVO vo) {
		
		return memberDAO.pwCheck(vo);
	}

	@Override
	public List<MemberVO> getMemberList(MemberVO vo) {
		System.out.println("2. serviceImpl : getMemberList() 호출");
		return memberDAO.getMemberList(vo);
	}


}
