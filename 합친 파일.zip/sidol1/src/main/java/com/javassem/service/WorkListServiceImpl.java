package com.javassem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.WorkListDAO;
import com.javassem.vo.WorkListVO;
@Service
public class WorkListServiceImpl implements WorkListService {

	@Autowired
	private WorkListDAO workDAO; 
	
	@Override
	public List<WorkListVO> getWorkList(WorkListVO vo) {
		System.out.println("2. WorkListServiceImpl : getWorkList() 호출");
		return workDAO.getWorkList(vo);
	}

	@Override
	public void insertWorkList(WorkListVO vo) {
		System.out.println("2. WorkListServiceImpl : insertWorkList() 호출");
		workDAO.insertWorkList(vo);
		
	}

}
