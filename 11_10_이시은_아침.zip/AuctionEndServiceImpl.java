package com.javassem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.AuctionEndDAO;
import com.javassem.vo.AuctionEndVO;

@Service
public class AuctionEndServiceImpl implements AuctionEndService{
	
	@Autowired
	private AuctionEndDAO end;

	@Override
	public AuctionEndVO getInfo(AuctionEndVO endvo) {
		return end.getInfo(endvo);
	}
}
