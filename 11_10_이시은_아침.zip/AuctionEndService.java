package com.javassem.service;

import com.javassem.vo.AuctionEndVO;

public interface AuctionEndService {
	

	AuctionEndVO getInfo(AuctionEndVO endvo);
}
