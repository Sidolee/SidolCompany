package com.javassem.dao;

import java.util.Date;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.AuctionEndVO;

@Repository 
public class AuctionEndDAOImpl implements AuctionEndDAO{

	@Autowired
	private SqlSessionTemplate sql;

	@Override
	public AuctionEndVO getInfo(AuctionEndVO endvo) {
		System.out.println("3. member.getInfo sql 요청");
		sql.selectOne("member.getInfo", endvo);
		if(endvo.getDELIVERY_ADDR()==null) {
			endvo.setA_NUM(0);
			endvo.setDELIVERY_ADDR("");
			endvo.setDELIVERY_COMPANY("");
			endvo.setDELIVERY_NUM("");
			endvo.setEND_BUYER("경매 미완료");
			endvo.setEND_COST(0);
			return endvo;
		}else {
			return sql.selectOne("member.getInfo", endvo);
		}
	}
}
