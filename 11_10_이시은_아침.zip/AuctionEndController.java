package com.javassem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javassem.service.Auction_infoService;
import com.javassem.service.Auction_ingService;
import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_ingVO;

@Controller
public class AuctionEndController {
	@Autowired
	private Auction_infoService info;
	@Autowired
	private Auction_ingService ing;
	
	@RequestMapping("changeAcon.do")
	@ResponseBody
	public String changeAcon(Auction_infoVO vo, Auction_ingVO ingvo) {
		System.out.println("changeAcon.do 요청 수락");
		System.out.println("vo.A_CONDITION 값 : " + vo.getA_CONDITION());
		
//		if(vo.getA_CONDITION() == "검토완료") {
//			// 사용자 화면에 검토 완료라고 떠야하는디 이게 action 이 별도로 필요한지 의문
//		} else if(vo.getA_CONDITION() == "상품접수완료"){
//			// 화면도 바꾸고 + 보관 장소 위치 update
//			
//		} else if (vo.getA_CONDITION() == "상품검토완료") {
//			// 화면 바꾸고 + ing 테이블에 insert -> 필요없잖아
//		} else if(vo.getA_CONDITION()== "경매중") {
//			// 딱히 없는ㄴ 듯
//		} else if (vo.getA_CONDITION() == "경매완료") {
//			// 현재 화면에 뜬 최고호가와 사용자 값 얻어와 auction_end 에 넣는과정
//			System.out.println("경매완료 선택의 경우로 들어옴");
//			ing.auctionEnd(ingvo);
//			
//		} else {
//			// 검토전, 검토중, 발송완료, 상품접수완료, 상품검토완료, 경매중
//			// 그냥 화면 바꾸기만 ㅎ사면 됨.
//		}
		if(vo.getA_CONDITION().equals("경매완료")) {
			System.out.println("경매완료 선택의 경우로 들어옴");
			ing.auctionEnd(ingvo);
		}
		info.changeAcon(vo);
		return "redirect:auction_list2.do?A_NUM="+vo.getA_NUM();
	}
	
	@RequestMapping("updateStorage.do")
	@ResponseBody 
	public String updateStorage(Auction_infoVO vo) {
		System.out.println("updateStorage.do 요청 수락");
		info.updateStorage(vo);
		return "";
	}
}
