package com.javassem.service;

import java.util.List;

import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_ingVO;
import com.javassem.vo.AuctioninfoVO;
import com.javassem.vo.MemberVO;

public interface Auction_infoService {
	
	public List<Auction_infoVO> selectByC(Auction_infoVO vo);
	
	public Auction_infoVO selectByA(Auction_infoVO vo); 
	
	public List<AuctioninfoVO> searchItem(AuctioninfoVO vo);
	
	public MemberVO getMembervo(Auction_infoVO vo);
	
	public List<Auction_infoVO> getAllAuctions(Auction_infoVO vo);
	
	public List<Auction_infoVO> getAuctions1(Auction_infoVO vo);
	
	public List<Auction_infoVO> getAuctions2(Auction_infoVO vo);
	
	public List<Auction_infoVO> getAuctions3(Auction_infoVO vo);
	
	public List<Auction_infoVO> getAuctions4(Auction_infoVO vo);
	
	public void changeAcon(Auction_infoVO vo);
	
	public void updateStorage(Auction_infoVO vo);
	

	
}
