package com.javassem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.Auction_infoDAO;
import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_ingVO;
import com.javassem.vo.AuctioninfoVO;
import com.javassem.vo.MemberVO;

@Service
public class Auction_infoServiceImpl implements Auction_infoService{
	
	@Autowired
	private Auction_infoDAO auction_infoDAO;
	
	@Override
	public List<Auction_infoVO> selectByC(Auction_infoVO vo) {
		System.out.println(vo.toString());
		return auction_infoDAO.selectByC(vo);
	}

	@Override
	public Auction_infoVO selectByA(Auction_infoVO vo) {
		System.out.println(vo.toString());
		return auction_infoDAO.selectByA(vo);
	}
	
	@Override
	public List<AuctioninfoVO> searchItem(AuctioninfoVO vo) {
		System.out.println("serviceImpl : searchItem 호출");
		return auction_infoDAO.searchItem(vo);
	}

	@Override
	public MemberVO getMembervo(Auction_infoVO vo) {
		// TODO Auto-generated method stub
		return auction_infoDAO.getMembervo(vo);
	}

	@Override
	public List<Auction_infoVO> getAllAuctions(Auction_infoVO vo) {
		System.out.println("2. serviceImpl 에서 getAllAuctions 호출");
		return auction_infoDAO.getAllAuctions(vo);
	}

	@Override
	public List<Auction_infoVO> getAuctions1(Auction_infoVO vo) {
		System.out.println("2. serviceImpl: getAuctions1 ");
		return auction_infoDAO.getAuctions1(vo);
	}

	@Override
	public List<Auction_infoVO> getAuctions2(Auction_infoVO vo) {
		System.out.println("2. serviceImpl: getAuctions2 ");
		return auction_infoDAO.getAuctions2(vo);
	}

	@Override
	public List<Auction_infoVO> getAuctions3(Auction_infoVO vo) {
		System.out.println("2. serviceImpl: getAuctions3 ");
		return auction_infoDAO.getAuctions3(vo);
	}

	@Override
	public List<Auction_infoVO> getAuctions4(Auction_infoVO vo) {
		System.out.println("2. serviceImpl: getAuctions4 ");
		return auction_infoDAO.getAuctions4(vo);
	}

	@Override
	public void changeAcon(Auction_infoVO vo) {
		auction_infoDAO.changeAcon(vo);
	}

	@Override
	public void updateStorage(Auction_infoVO vo) {
		auction_infoDAO.updateStorage(vo);
		
	}



}
