package com.javassem.dao;

import com.javassem.vo.AuctionEndVO;

public interface AuctionEndDAO {
	
	public AuctionEndVO getInfo(AuctionEndVO endvo);
	

}
