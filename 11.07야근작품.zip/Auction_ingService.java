package com.javassem.service;

import com.javassem.vo.Auction_ingVO;

public interface Auction_ingService {
	void joinAuction(Auction_ingVO vo);
	Auction_ingVO getAuction_ingInfo(Auction_ingVO ingvo);
	Auction_ingVO getAuction_ingInfomember(Auction_ingVO ingvo);

}
