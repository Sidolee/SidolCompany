package com.javassem.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.Auction_ingVO;

@Repository
public class Auction_ingDAOImpl implements Auction_ingDAO{
	
	@Autowired
	private SqlSessionTemplate sql;
	
	@Override
	public void joinAuction(Auction_ingVO vo) {
		System.out.println("3. Auction_ingDAOImpl : sql joinAuction() 호출");
		int result = sql.insert("member.joinAuction", vo);
		System.out.println("수행결과 : " + result);
		
	}

	@Override
	public Auction_ingVO getAuction_ingInfo(Auction_ingVO ingvo) {
		System.out.println("getAuction_ingInfo 작업"+ingvo.toString());
		Auction_ingVO result = sql.selectOne("member.getAuctioninginfo",ingvo);
		System.out.println("getAuction_ingInfo매퍼에서 받은 데이터 작업"+result.toString());

		return result;
	}

	@Override
	public Auction_ingVO getAuction_ingInfomember(Auction_ingVO ingvo) {
		// TODO Auto-generated method stub
		return  sql.selectOne("member.getAuctionIngInfoMember",ingvo);
	}
	
}
