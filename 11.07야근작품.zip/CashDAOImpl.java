package com.javassem.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.CashVO;

@Repository
public class CashDAOImpl implements CashDAO {
	
	@Autowired
	private SqlSessionTemplate mybatis;
	
	@Override
	public void updateAccount(CashVO vo) {
		System.out.println("CashDAOImpl : updateAccount() 호출");
		int result = mybatis.update("member.updateAccount", vo);
		System.out.println("mybatis update 종료");
		System.out.println("수행결과 : " + result);
		
	}

	@Override
	public CashVO getMyAccount(CashVO vo) {
		System.out.println("CashDAOImpl : getMyAccount() 호출");
		return mybatis.selectOne("member.getMyAccount", vo);
	}

	@Override
	public void chargeAccount(CashVO vo) {
		System.out.println("CashDAOImpl : chargeAccount() 호출");
		int result =  mybatis.update("member.chargeAccount", vo);
		System.out.println("mybatis update 종료");
		System.out.println("수행결과 : " + result);
		
	}

}
