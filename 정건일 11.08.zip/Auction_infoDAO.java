package com.javassem.dao;

import java.util.List;

import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.AuctioninfoVO;
import com.javassem.vo.MemberVO;

public interface Auction_infoDAO {
	
	public List<Auction_infoVO> selectByC(Auction_infoVO vo);
	
	public Auction_infoVO selectByA(Auction_infoVO vo); 
	
	public List<AuctioninfoVO> searchItem(AuctioninfoVO vo);
	public MemberVO getMembervo(Auction_infoVO vo);
}
