package com.javassem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javassem.service.Notice_Question_WarnService;
import com.javassem.vo.Auction_warnVO;
import com.javassem.vo.QuestionVO;

@Controller
public class Notice_Question_WarnController {
	
	/*****************************************************************
	 * 문의글 작성, 확인, 수정, 삭제
	 * 
	 */
	@Autowired
	private Notice_Question_WarnService notice_Question_WarnService;
	
	@RequestMapping("Question_Wit.do")
	private String Question_Wit(QuestionVO vo) {
		System.out.println("전달값 : " + vo.toString());
		notice_Question_WarnService.Question_Wit(vo);
		
		return "redirect:info_Faq.do";
	}
	
	@RequestMapping(value = "info_ck_page.do", params = {"Q_NUM"})
	private void Question_Page(QuestionVO vo, Model model) {
		QuestionVO Result = notice_Question_WarnService.Question_Page(vo);
		System.out.println(Result);
		model.addAttribute("question", Result);
	}
	
	//info_edit_Wit.do
	public void name() {
		
	}
	
	@RequestMapping("Question_Update.do")
	private String Question_Update(QuestionVO vo) {
		System.out.println("전달값 : " + vo.toString());
		int result = notice_Question_WarnService.Question_Update(vo);
		
		if(result == 0) {
		System.out.println("수정 실패");
		return "redirect:info_Faq.do";
		}else { 
			System.out.println("수정 성공");
			return "redirect:info_Faq.do";
		}
	}
	
	@RequestMapping(value = "Question_Delete.do")
	private String Question_Delete(QuestionVO vo) {
		System.out.println(vo.toString());
		notice_Question_WarnService.Question_Delete(vo);
		return "redirect:info_Faq.do";
	}
	
	/*****************************************************************
	 * 신고글 작성, 확인
	 * 
	 */
	
	@RequestMapping("Warn_Wit.do")
	private String Warn_Wit(Auction_warnVO vo) {
		System.out.println("전달값 : " + vo.toString());
		notice_Question_WarnService.Warn_Wit(vo);
		return "redirect:info_Faq.do";
	}
	
	/*
	@RequestMapping(value = "info_Warn_page.do", params = {""})
	private void Warn_Page(Auction_warnVO vo, Model model) {
		Auction_warnVO Result = notice_Question_WarnService.Warn_Page(vo);
		System.out.println(Result);
		model.addAttribute("Warn", Result);
	}
	*/
}
