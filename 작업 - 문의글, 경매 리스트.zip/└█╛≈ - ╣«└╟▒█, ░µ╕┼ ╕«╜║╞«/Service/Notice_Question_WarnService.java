package com.javassem.service;

import com.javassem.vo.Auction_warnVO;
import com.javassem.vo.QuestionVO;

public interface Notice_Question_WarnService {

	public void Question_Wit(QuestionVO vo);
	
	public QuestionVO Question_Page(QuestionVO vo);
	
	public int Question_Update(QuestionVO vo);
	
	public void Question_Delete(QuestionVO vo);
	
	public void Warn_Wit(Auction_warnVO vo);
	
	public Auction_warnVO Warn_Page(Auction_warnVO vo);
}
