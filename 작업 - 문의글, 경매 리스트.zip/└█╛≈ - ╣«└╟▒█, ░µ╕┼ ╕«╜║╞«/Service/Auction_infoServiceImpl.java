package com.javassem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.Auction_infoDAO;
import com.javassem.vo.Auction_infoVO;

@Service
public class Auction_infoServiceImpl implements Auction_infoService{
	
	@Autowired
	private Auction_infoDAO auction_infoDAO;
	
	@Override
	public List<Auction_infoVO> selectByC(Auction_infoVO vo) {
		System.out.println(vo.toString());
		return auction_infoDAO.selectByC(vo);
	}

	@Override
	public Auction_infoVO selectByA(Auction_infoVO vo) {
		System.out.println(vo.toString());
		return auction_infoDAO.selectByA(vo);
	}

}
