package com.javassem.vo;

import java.util.Date;

import lombok.Data;

@Data
public class Auction_infoVO {
	
	private int A_NUM;			// 상품번호
	private String A_SELLER;	// 판매자
	private String A_TITLE;		// 제목
	private String A_CONTENT;	// 내용
	private int START_COST;		// 시작가
	private String A_IMG1;		// 이미지1
	private String A_IMG2;		// 2
	private String A_IMG3;		// 3
	private int A_LIMIT;		// 참가 인원 제한
	private int A_WARN;			// 경고 횟수
	private int A_ACCESS;		// 접근한 기록
	private String A_DISPLAY;	// 공개여부
	private int A_WISH;			// 찜인원
	private Date A_DATE;		// 게시글 등록일
	private Date A_STARTDAY;	// 경매 시작일
	private Date A_ENDDAY;		// 종료일
	private String S_NUM;		// 보관위치 코드
	private int C_ID;			// 카테고리 코드
	private String A_REALIMG;	// DB 이미지 이름
	private long A_IMGSIZE;		// 파일 크기
	private String A_REALIMG2;	// 2
	private long A_IMGSIZE2;	// 2
	private String A_REALIMG3;	// 3
	private long A_IMGSIZE3;	// 3
}
