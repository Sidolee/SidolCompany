package com.javassem.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.Auction_warnVO;
import com.javassem.vo.QuestionVO;

@Repository
public class Notice_Question_WarnDAOImpl implements Notice_Question_WarnDAO{

	@Autowired
	private SqlSessionTemplate mybatis;

	@Override
	public void Question_Wit(QuestionVO vo) {
		System.out.println("insertQuestion 작업");
		int result = mybatis.insert("question.insertQuestion", vo);
		System.out.println(result);
	}

	@Override
	public QuestionVO Question_Page(QuestionVO vo) {
		System.out.println("selectQuestionByNum 작업");
		return mybatis.selectOne("question.selectQuestionByNum", vo);
	}
	
	@Override
	public int Question_Update(QuestionVO vo) {
		System.out.println("updateQuestionByNumPw 작업");
		return mybatis.update("question.updateQuestionByNumPw", vo);
	}

	@Override
	public void Question_Delete(QuestionVO vo) {
		System.out.println("deleteQuestion 작업");
		int result = mybatis.delete("question.deleteQuestionByNumPw", vo);
		System.out.println(result);
	}
	
	
	@Override
	public void Warn_Wit(Auction_warnVO vo) {
		System.out.println("insertWarn 작업");
		int result = mybatis.insert("auction_warn.insertWarn", vo);
		System.out.println(result);
	}

	@Override
	public Auction_warnVO Warn_Page(Auction_warnVO vo) {
		System.out.println("selectWarn 작업");
		return mybatis.selectOne("auction_warn.selectByNum", vo);
	}


}
