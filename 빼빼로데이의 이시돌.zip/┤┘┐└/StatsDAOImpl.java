package com.javassem.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class StatsDAOImpl implements StatsDAO{

	@Autowired
	private SqlSessionTemplate sql;
	
	// 그날 총 거래금액
	@Override
	public Integer getTodayTotalCost() {
		int result = sql.selectOne("stats.getTodayTotalCost");
		System.out.println("그날 총 거래 금액 : " + result);
		return result;
	}
	
	// 진행중인 경매 건수
	@Override
	public Integer getTodayIngCount() {
		int result = sql.selectOne("stats.getTodayIngCount");
		System.out.println("그날 진행중인 경매 수 : " + result);
		return result;
	}
	
	// 그날 완료된 경매 건수
	@Override
	public Integer getTodayEndCount() {
		int result = sql.selectOne("stats.getTodayEndCount");
		System.out.println("그날 완료된 경매 수 : " + result);
		return result;
	}

}
