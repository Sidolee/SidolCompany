package com.javassem.service;

public interface StatsService {
	public Integer getTodayTotalCost();
	public Integer getTodayIngCount();
	public Integer getTodayEndCount();
}
