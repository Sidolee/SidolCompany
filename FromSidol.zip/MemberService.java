package com.javassem.service;

import java.util.List;

import com.javassem.vo.MemberVO;

public interface MemberService {
	
	void insertMember(MemberVO vo);
	
	void updateMember(MemberVO vo);
	
	void deleteMember(MemberVO vo);
	
	MemberVO login(MemberVO vo);
	
	MemberVO pwCheck(MemberVO vo);
	
	List<MemberVO> getMemberList(MemberVO vo);
	

}
