package com.javassem.vo;

import lombok.Data;

@Data
public class MemberVO {
	
	private String M_ID;
	private String M_PW;
	private String M_NAME;
	private String M_TEL;
	private String M_ADDR;
	private String M_CATEGORY1;
	private String M_AGREE_INFO;
	private String M_AGREE_MARKETING;
	private String M_BIRTH;
	private String M_GENDER;
	private String M_GRADE;
	private String M_PREMIUM;
	private String M_EMAIL;
	


}
