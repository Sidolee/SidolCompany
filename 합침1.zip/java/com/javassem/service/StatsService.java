package com.javassem.service;

public interface StatsService {
	public Integer getTodayTotalCost();
	public Integer getTodayIngCount();
	public Integer getTodayEndCount();
	public Integer getTodayAccess();
	public Integer getUnrepliedQuestion();
	public Integer getUnProcessedWarn();
}
