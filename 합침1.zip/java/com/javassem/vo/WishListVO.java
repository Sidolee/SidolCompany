package com.javassem.vo;

import lombok.Data;

@Data
public class WishListVO {
	private String W_ID;
	private Integer W_PRODUCT;
	
	private Integer COUNT;
}
