package com.javassem.vo;

import lombok.Data;

@Data
public class StorageVO {
	private Integer S_NUM;
	private String S_ADDR;
	private String S_MANAGER;
	private Integer A_NUM;
}
