package com.javassem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javassem.service.AuctionEndService;
import com.javassem.service.Auction_infoService;
import com.javassem.service.Auction_ingService;
import com.javassem.vo.AuctionEndVO;
import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_ingVO;

@Controller
public class AuctionEndController {
	@Autowired
	private Auction_infoService info;
	@Autowired
	private Auction_ingService ing;
	
	@Autowired
	private AuctionEndService end;
	
	// 메소드명 : changeAcon
	// 역할 : 관리자 모드의 경매관리에서 상품의 유통상태 변경 및 그에 따른 DB상의 값 처리
	@RequestMapping("changeAcon.do")
	@ResponseBody
	public String changeAcon(Auction_infoVO vo, Auction_ingVO ingvo) {
		System.out.println("changeAcon.do 요청 수락");
		System.out.println("vo.A_CONDITION 값 : " + vo.getA_CONDITION());
		
//		if(vo.getA_CONDITION() == "검토완료") {
//			// 사용자 화면에 검토 완료라고 떠야하는디 이게 action 이 별도로 필요한지 의문
//		} else if(vo.getA_CONDITION() == "상품접수완료"){
//			// 화면도 바꾸고 + 보관 장소 위치 update
//			
//		} else if (vo.getA_CONDITION() == "상품검토완료") {
//			// 화면 바꾸고 + ing 테이블에 insert -> 필요없잖아
//		} else if(vo.getA_CONDITION()== "경매중") {
//			// 딱히 없는ㄴ 듯
//		} else if (vo.getA_CONDITION() == "경매완료") {
//			// 현재 화면에 뜬 최고호가와 사용자 값 얻어와 auction_end 에 넣는과정
//			System.out.println("경매완료 선택의 경우로 들어옴");
//			ing.auctionEnd(ingvo);
//			
//		} else {
//			// 검토전, 검토중, 발송완료, 상품접수완료, 상품검토완료, 경매중
//			// 그냥 화면 바꾸기만 ㅎ사면 됨.
//		}
		if(vo.getA_CONDITION().equals("경매완료")) {
			System.out.println("경매완료 선택의 경우로 들어옴");
			ing.auctionEnd(ingvo);
		}
		info.changeAcon(vo);
		return "redirect:auction_list2.do?A_NUM="+vo.getA_NUM();
	}
	
	// 메소드명 : updateStorage
	// 역할 : 관리자 - 경매관리에서 상품의 보관 위치 update 
	@RequestMapping("updateStorage.do")
	@ResponseBody 
	public String updateStorage(Auction_infoVO vo) {
		System.out.println("updateStorage.do 요청 수락");
		info.updateStorage(vo);
		return "redirect:auction_list2.do?A_NUM="+vo.getA_NUM();
	}
	
	// 메소드명 : updateDeliveryInfo
	// 역할 : 관리자 모드에서 배송 관련 정보 입력 시 DB 에 반영 -> 아직 ajax 안함
	@RequestMapping("updateDeliveryInfo.do")
	public String updateDeliveryInfo(AuctionEndVO endvo) {
		System.out.println("배송정보 입력 컨트롤러 시작");
		end.updateDeliveryInfo(endvo);
		return "redirect:auction_list2.do?A_NUM="+endvo.getA_NUM();
	}
	// 메소드명 : finishedByQuickPrice
	// 역할 : 경매 중 즉시입찰가 도달 시 자동으로 경매 종료 처리 + end 테이블에 값 입력
	// 인자 : A_NUM, ING_COST, ING_BUYER
	@RequestMapping("/finishedByQuickPrice.do")
	@ResponseBody
	public String finishedByQuickPrice(AuctionEndVO endvo, Auction_ingVO ingvo, Auction_infoVO fovo) {
		// 1. 우선 ing 테이블에 값 입력
		System.out.println("1. ing에 값 입력");
		ing.joinAuction(ingvo);
		// 2. end 테이블에도 값 입력
		System.out.println("info 테이블 경매완료 처리 update");
		fovo.setA_CONDITION("경매완료");
		info.changeAcon(fovo);
		// 3. info 테이블에서 경매완료 상태로 처리
		System.out.println("end 테이블에 값 입력");
		ing.auctionEnd(ingvo);
		
		return "redirect:bid_Pc.do?A_NUM="+ingvo.getA_NUM()+"&M_ID="+ingvo.getING_BUYER()+"&ING_BUYER="+ingvo.getING_BUYER();
		// "redirect:bid_Pc.do?A_NUM=" +ingvo.getA_NUM + "&M_ID=" + M_ID 얻어오고 + "&ING_BUYER=" + ing_buyer
	}
}
