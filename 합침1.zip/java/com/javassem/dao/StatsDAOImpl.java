package com.javassem.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class StatsDAOImpl implements StatsDAO{

	@Autowired
	private SqlSessionTemplate sql;
	
	// 그날 총 거래금액
	@Override
	public Integer getTodayTotalCost() {
		int result = sql.selectOne("stats.getTodayTotalCost");
		System.out.println("그날 총 거래 금액 : " + result);

		return result;
	}
	
	// 진행중인 경매 건수
	@Override
	public Integer getTodayIngCount() {
		int result = sql.selectOne("stats.getTodayIngCount");
		System.out.println("그날 진행중인 경매 수 : " + result);
		return result;
	}
	
	// 그날 완료된 경매 건수
	@Override
	public Integer getTodayEndCount() {
		int result = sql.selectOne("stats.getTodayEndCount");
		System.out.println("그날 완료된 경매 수 : " + result);
		return result;
	}
	
	// 오늘 접속자 수
	@Override
	public Integer getTodayAccess() {
		int result = sql.selectOne("stats.getTodayAccess");
		System.out.println("오늘 접속자 수 : " +result);
		return result;
	}
	
	// 답변 안 된 문의글 수
	@Override
	public Integer getUnrepliedQuestion() {
		int result = sql.selectOne("stats.getUnrepliedQuestion");
		System.out.println("답변 안 된 문의글 : " + result);
		return result;
	}

	@Override
	public Integer getUnProcessedWarn() {
		int result = sql.selectOne("stats.getUnProcessedWarn");
		System.out.println("처리 미완료 신고 : " + result);
		return result;
	}

}
