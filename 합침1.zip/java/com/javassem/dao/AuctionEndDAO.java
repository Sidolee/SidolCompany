package com.javassem.dao;

import com.javassem.vo.AuctionEndVO;
import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_ingVO;

public interface AuctionEndDAO {
	
	public AuctionEndVO getInfo(Auction_infoVO info);
	
	public void updateDeliveryInfo(AuctionEndVO endvo);
	
	int auctionEndByTime(Auction_ingVO info);
}
