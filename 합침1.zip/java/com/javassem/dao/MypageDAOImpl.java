package com.javassem.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.Auction_EndVO;
import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_ingVO;
import com.javassem.vo.MypageDeliverylistVO;
import com.javassem.vo.MypageauctionlistVO;
import com.javassem.vo.MypagewishlistVO;
import com.javassem.vo.WishListVO;

@Repository
public class MypageDAOImpl implements MypageDAO{
	
	@Autowired
	private SqlSessionTemplate mybatis;
	
	// 낙찰받은 경매리스트 불러오기
	@Override
	public List<MypageauctionlistVO> getMypageauctionlist(Auction_EndVO endvo) {
		List<MypageauctionlistVO> result=mybatis.selectList("mypage.getMypageauctionlist", endvo);
		return result;
	}
	
	
	// 낙찰받은 경매리스트 검색 불러오기
		@Override
		public List<MypageauctionlistVO> mypageauctionlistsearch(Auction_EndVO endvo) {
			List<MypageauctionlistVO> result=mybatis.selectList("mypage.searchItem", endvo);
			return result;
		}
	
	// 참여했던 경매의 리스트 불러오기
	@Override
	public List<Auction_infoVO> getMypageauctioninglist(Auction_ingVO ingvo){
		System.out.println(" 참여했던 경매의 리스트 불러오기 DAO의 바이어 이름"+ingvo.getING_BUYER());
		List<Auction_infoVO> result = mybatis.selectList("mypage.getauctionlist", ingvo);
		System.out.println(" 참여했던 경매의 리스트 불러오기 DAO"+result);
		return result;
		
	}

	
	//찜 목록 리스트 불러오기
	@Override
	public List<MypagewishlistVO> getWishlist(WishListVO vo) {
		 
		
		return mybatis.selectList("mypage.getWishlist", vo);
	}
	
	//찜 목록 삭제
	@Override
	public void deleteWishlist(WishListVO vo) {
		// TODO Auto-generated method stub
		System.out.println("DAOIMPLE deleteWishlist 작업 ===> :"+ vo.toString());

		mybatis.delete("mypage.deleteWishlist",vo);
		

	}

	//배송 목록 불러오기
	@Override
	public List<MypageDeliverylistVO> getDeliverylist(Auction_EndVO endvo) {
		// TODO Auto-generated method stub
		return mybatis.selectList("mypage.getDeliverylist", endvo);
	}

	//배송지입력하기 >__<!
	@Override
	public void mypagedeliverymodify(Auction_EndVO endvo) {
		System.out.println("mypagedeliverymodifyDAOIMPL ==> mypagedeliverymodify의 Auction_EndVO값 : " + endvo.toString());
		int result = mybatis.update("mypage.mypagedeliverymodify",endvo);
		//성공시 : 1 실패시 : 0
		System.out.println("딜리버리업데이트결과 : " + result);

		
	}
	 
}
