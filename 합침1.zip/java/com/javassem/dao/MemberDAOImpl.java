package com.javassem.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.MemberVO;

@Repository
public class MemberDAOImpl implements MemberDAO{

	@Autowired
	private SqlSessionTemplate mybatis;

	@Override
	public void insertMember(MemberVO vo) {
		System.out.println("===> Mybatis insertMember() 호출");
		System.out.println(vo.toString());
		int result = mybatis.insert("member.insertMember", vo); 
		System.out.println("입력결과 : " + result);

	}


	@Override
	public void updateMember(MemberVO vo) {
		// TODO Auto-generated method stub
		System.out.println("===> 여기는 MemberDAOImpl ! Mybatis updateMember() 호출");
		int result = mybatis.update(namespace + "updateMember", vo);
		System.out.println("mybatis.update 종료");
		System.out.println("수행결과 : " + result);
	}

	@Override
	public void deleteMember(MemberVO vo) {
		// TODO Auto-generated method stub

	}

	@Override
	public MemberVO login(MemberVO vo) {
		System.out.println("===> 여기는 MemberDAOImpl ! Mybatis login() 호출");
		return mybatis.selectOne(namespace + "login", vo);

	}


	@Override
	public MemberVO pwCheck(MemberVO vo) {
		System.out.println("===> 여기는 MemberDAOImpl! myatis pwCheck() 호출");
		return mybatis.selectOne(namespace + "pwCheck", vo);
	}



	@Override
	public List<MemberVO> getMemberList(MemberVO vo) {
		System.out.println("3. DAOImpl : getMemberList() 호출");
		return mybatis.selectList("member.getMemberList", vo);
	}



	@Override
	public List<MemberVO> getMemberByCondition(MemberVO vo) {
		System.out.println("3. DAOImpl : getMemberByCondition() 호출");
		return mybatis.selectList("member.getMemberByCondition", vo);
	}



	@Override
	public int idCheck(String M_ID) {
		System.out.println("3. DAOImpl : Mybatis idCheck() 호출받음");
		System.out.println("M_ID 의 값 : " + M_ID);
		int result = mybatis.selectOne("member.idCheck",  M_ID);
		System.out.println("result : " + result);

		return result;

	}


	@Override
	public MemberVO getPersonalData(MemberVO vo) {
		System.out.println("3. DAO : member.getPersonalData sql 날릴거임");
		System.out.println("3. 다오 : " + vo.getM_ID());
		MemberVO result = mybatis.selectOne("member.getPersonalData", vo);
		System.out.println("3. DAO 에서 값 체크 : " + result);
		return result;
	}


	@Override
	public void changeGrade(MemberVO vo) {
		System.out.println("3. DAO : member.changeGrade sql 날릴 거임.");
		int result = mybatis.update("member.changeGrade", vo);
		System.out.println("수행결과 : " +result);
		
	}

	// 로그인 시 로그 데이터 테이블에 로그인 이력 추가
	@Override
	public void isnertLogData(MemberVO vo) {
		int result = mybatis.insert("stats.insertLogData", vo);
		System.out.println("수행결과 : " + result);
		
	}





}
