package com.javassem.dao;

import java.util.List;

import com.javassem.vo.CashVO;

public interface CashDAO {
	
	CashVO getMyAccount(CashVO vo);

	void updateAccount(CashVO vo);
	
	void chargeAccount(CashVO vo);
}
