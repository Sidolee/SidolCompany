package com.javassem.dao;

import com.javassem.vo.StorageVO;

public interface StorageDAO {
	StorageVO getInfo(StorageVO vo);

}
