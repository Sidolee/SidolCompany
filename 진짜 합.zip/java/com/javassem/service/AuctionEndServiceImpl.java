package com.javassem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.AuctionEndDAO;
import com.javassem.vo.AuctionEndVO;
import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_ingVO;

@Service
public class AuctionEndServiceImpl implements AuctionEndService{
	
	@Autowired
	private AuctionEndDAO end;

	@Override
	public AuctionEndVO getInfo(Auction_infoVO info) {
		return end.getInfo(info);
	}

	@Override
	public void updateDeliveryInfo(AuctionEndVO endvo) {
		end.updateDeliveryInfo(endvo);
		
	}

	@Override
	public int auctionEndByTime(Auction_ingVO info) {
		return end.auctionEndByTime(info);
	}
}
