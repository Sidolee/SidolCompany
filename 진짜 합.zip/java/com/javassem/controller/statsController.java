package com.javassem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javassem.service.StatsService;
import com.javassem.service.WorkListService;
import com.javassem.vo.StatsVO;
import com.javassem.vo.WorkListVO;

@Controller
public class statsController {
	@Autowired
	StatsService stats;
	WorkListService work;
	
	

	// 메소드명 : getMainStats
	// 역할 : 관리자 메인 페이지에 통계 자료 가져옴
	@RequestMapping("/main.do")
	public void getMainStats(Model m, StatsVO svo, WorkListVO wvo){
		System.out.println("stats 컨트롤러까지 왔나");
		// 1. 그날의 총 거래금액 
//		int result = stats.getTodayTotalCost(); // svo 의 total cost 에 총 거래금액이 담겨잇아
//		System.out.println(result);
//		svo.setTotalCost(result);
		svo.setTotalCost(stats.getTodayTotalCost());
		System.out.println("svo 에 값이 잘 담겼는지 : " + svo.getTotalCost());
		// 2. 그날 진행중인 경매 건수
		svo.setIngCount(stats.getTodayIngCount()); 
		System.out.println("svo에 값이 잘 담겼는지 : " + svo.getIngCount());
		// 3. 그날 완료된 경매 건수
		svo.setEndCount(stats.getTodayEndCount()); 
		
		// 1~3 까지 model 에 붙이기 -> 으앙 성공 ㅠㅠ
		m.addAttribute("dailyTotal", svo);
		// 4. 최근 완료된 작업목록 5개 가져오기
		//System.out.println("이제 작업목록 가져와야지 왜 안가져와 ㅜㅜ");
		//List<WorkListVO> workList = work.get5WorkList();
		//m.addAttribute("5Work", workList);
		
		// 안되니까 버리고 오늘접속자 수 가져오기
		svo.setTodayAccess(stats.getTodayAccess());
		System.out.println("svo 에 잘 담겼는지 : " + svo.getTodayAccess());
		
		// 답변 안 된 문의글 수
		svo.setUnRepliedQuestion(stats.getUnrepliedQuestion());
		System.out.println("svo에 잘 담겼는지 : " + svo.getUnRepliedQuestion());
		
		// 신고게시글 처리 안된거
		svo.setUnProcessedWarn(stats.getUnProcessedWarn());
		System.out.println("svo에 잘 담겼는지 : " + svo.getUnProcessedWarn());
		
		
		
	}
}
