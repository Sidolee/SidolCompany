package com.javassem.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_ingVO;
import com.javassem.vo.AuctioninfoVO;
import com.javassem.vo.MemberVO;

@Repository 
public class Auction_infoDAOImpl implements Auction_infoDAO{

	@Autowired
	private SqlSessionTemplate mybatis;
	
	@Override
	public List<Auction_infoVO> selectByC(Auction_infoVO vo) {
		System.out.println("selectByC 작업");
		return mybatis.selectList("auction_info.selectByC", vo);
	}

	@Override
	public Auction_infoVO selectByA(Auction_infoVO vo) {
		System.out.println("selectByA 작업");
		Auction_infoVO result = mybatis.selectOne("auction_info.selectByA", vo);
		System.out.println("selectByA" + result.toString());
		vo.setA_CONDITION(result.getA_CONDITION());
		return result;
	}
	
	@Override
	public List<AuctioninfoVO> searchItem(AuctioninfoVO vo) {
		System.out.println("===> Mybatis.searchItem() 호출");
		return mybatis.selectList("member.searchItem", vo);
	}
	
	@Override
	public MemberVO getMembervo(Auction_infoVO vo) {
		// TODO Auto-generated method stub
		
		MemberVO result = mybatis.selectOne("member.getMembervo", vo);
		if(result==null) {
			result.setM_GRADE("미정");
			result.setM_ID("미정");
			result.setM_NAME("미정");
			System.out.println("if null : getMemberVO : " + result.toString());
			return result;
			
		}
		
		System.out.println("null이 아닌 : "+ result.toString());
		return mybatis.selectOne("member.getMembervo", vo);
	}

	@Override
	public List<Auction_infoVO> getAllAuctions(Auction_infoVO vo) {
		System.out.println("3. DAOImpl : getAllAuctions() 호출");
		return mybatis.selectList("member.getAllAuctions", vo);
	}

	@Override
	public List<Auction_infoVO> getAuctions1(Auction_infoVO vo) {
		System.out.println("3. DAOImpl : getAuctions1() 호출");
		return mybatis.selectList("member.getAuctions1", vo);
	}

	@Override
	public List<Auction_infoVO> getAuctions2(Auction_infoVO vo) {
		System.out.println("3. DAOImpl : getAuctions2() 호출");
		return mybatis.selectList("member.getAuctions2", vo);
	}

	@Override
	public List<Auction_infoVO> getAuctions3(Auction_infoVO vo) {
		System.out.println("3. DAOImpl : getAuctions3() 호출");
		return mybatis.selectList("member.getAuctions3", vo);
	}

	@Override
	public List<Auction_infoVO> getAuctions4(Auction_infoVO vo) {
		System.out.println("3. DAOImpl : getAuctions4() 호출");
		return mybatis.selectList("member.getAuctions4", vo);
	}

	@Override
	public void changeAcon(Auction_infoVO vo) {
		System.out.println("3. DAO 에서 member.changeAcon sql 전송");
		int result = mybatis.update("member.changeAcon", vo);
		System.out.println("수행결과 : " + result);
		
	}

	@Override
	public void updateStorage(Auction_infoVO vo) {
		int result = mybatis.update("member.updateStorage", vo);
		System.out.println("수행결과 : " + result);
	}

	@Override
	public int updateConditionByNum(Auction_infoVO vo) {
		System.out.println("updateConditionByNum 작업");
		return mybatis.update("auction_info.updateConditionByNum", vo);
	}


	
}
