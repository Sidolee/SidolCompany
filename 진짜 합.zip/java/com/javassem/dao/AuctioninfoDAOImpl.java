//<!--11.07.버전  -->
package com.javassem.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.AuctioninfoVO;

@Repository("auctioninfoDAO")
public class AuctioninfoDAOImpl implements AuctioninfoDAO{
	
	@Autowired
	private SqlSessionTemplate mybatis;
	
	@Override
	public int insertAuctioninfo(AuctioninfoVO vo) {
		System.out.println("AuctioninfoDAOImple 실행결과"+vo.toStringAcutioninfoinsert());
		System.out.println("AuctioninfoDAOImple 컨디션 넘어가는지 확인 : "+vo.getA_CONDITION());

		return mybatis.insert("auctioninfo.insertAuctioninfo",vo);
	}

	@Override
	public List<AuctioninfoVO> getAuctioninfoList(AuctioninfoVO vo) {
		System.out.println("===> Mybatis getAuctioninfoList() 호출");
		return mybatis.selectList("auctioninfo.getAuctioninfoList", vo);
	}

	@Override
	public AuctioninfoVO getAuctioninfo(AuctioninfoVO vo) {
		System.out.println("===> Mybatis getAuctioninfo() 호출");
		return mybatis.selectOne("auctioninfo.getAuctioninfo", vo);
	}

	@Override
	public void deleteAuctioninfo(AuctioninfoVO vo) {
		System.out.println("====> Mybatis bid_Delete"+vo.toStringAll());

		mybatis.delete("auctioninfo.deleteAuctioninfo",vo);
	}

	@Override
	public void modifyAuctioninfo(AuctioninfoVO vo) {
		// TODO Auto-generated method stub
		System.out.println("====> Mybatis bid_Modify"+vo.toStringAll());
		mybatis.delete("auctioninfo.updateAuctioninfo",vo);

	}

	@Override
	public void deleteAuctioninfolist(List<AuctioninfoVO> vo) {
		System.out.println("====> Mybatis bid_Deletelist"+ vo);

		mybatis.delete("auctioninfo.deleteAuctioninfolist",vo);
		
	}

}

