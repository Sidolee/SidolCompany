package com.javassem.dao;

import java.util.List;

import com.javassem.vo.WorkListVO;

public interface WorkListDAO {
	
	List<WorkListVO> getWorkList(WorkListVO vo);
	
	void insertWorkList(WorkListVO vo);
}
