package com.javassem.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.CategoryVO;
@Repository
public class CategoryDAOImpl implements CategoryDAO{

	@Autowired
	private SqlSessionTemplate sql;
	
	@Override
	public CategoryVO getCategory(CategoryVO vo) {
		System.out.println("3. DAO : member.getCategory sql 요청");
		return sql.selectOne("member.getCategory", vo);
	}

}
