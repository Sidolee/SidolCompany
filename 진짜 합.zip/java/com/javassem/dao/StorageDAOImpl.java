package com.javassem.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.StorageVO;

@Repository
public class StorageDAOImpl implements StorageDAO{
	@Autowired
	private SqlSessionTemplate sql;

	@Override
	public StorageVO getInfo(StorageVO svo) {
		System.out.println("member.getStorageInfo sql 날림");

		return sql.selectOne("member.getStorageInfo", svo);
		
		
	}
}
