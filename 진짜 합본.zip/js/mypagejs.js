/**
 * 
 */
 
  $(function(){
    		
     
    		
  
  	//찜 리스트 삭제
  	 	$('[id^="deletebtn"]').click(function(){
  		
  		var index = $(this).attr('id').replace('deletebtn', '');
        var W_PRODUCT = $('#getNum' + index).val();
        var W_ID = $('#getId' + index).val();
   	
  			
  			$.ajax({
 			type	: 'get',
 			data	: {W_ID  , W_PRODUCT},
 			url		: '/sidol1/deletewishlist.do',
 			success	: function(){
 							alert("찜목록에서 삭제되었습니다.");
 							
 							 
 			 },
 			error	: function(err){alert('작업 그 자체의 실패');}
 		
 		}); // end of 	ajax
 		
 		
 		
  	
  		}); // end of 찜 리스트 삭제
  		
  		
  		
  		// 찜리스트에서 경매현장으로 넘어가기.
  		$('[id^="joinauctionbtn"]').click(function(){
  		
  		var index = $(this).attr('id').replace('joinauctionbtn', '');
  		
        var A_NUM = $('#getNum' + index).val();
        var ING_BUYER = $('#getId' + index).val();
   	    var M_ID = $('#getId' + index).val();
   	       		console.log(A_NUM);	
   	       		console.log(ING_BUYER);	
   	       		console.log(M_ID);	
   	    
   	    var url = "/sidol1/bid_Pc.do" +
   		 "?A_NUM=" + encodeURIComponent(A_NUM) +
   		 "&M_ID=" + encodeURIComponent(M_ID) +
   		 "&ING_BUYER=" + encodeURIComponent(ING_BUYER);

			window.location.href = url;

  		}); // end of 찜리스트에서 경매현장으로 넘어가기.
  	
  	
  		function goingbid (A_NUM, M_ID, ING_BUYER) {
  			$.ajax({
 				type	: 'post',
 				data	: {A_NUM, M_ID, ING_BUYER},
 				url		: '/sidol1/goingbid_Pc.do',
 				success	: function(response){
 						alert("Redirected to: " + response);	
 						//window.location.href = response;
 				 },
 				error	: function(err){alert('작업 그 자체의 실패');}
 		
 			}); // end of ajax
  		}
  		
  		
	//카테고리버튼 드롭다운 토글
		$('#categorybtn').click(function(){
		
			  var isOpen = $('.btn-group').hasClass('open');

		        // Remove 'active' class from all links
		        if (isOpen) {
		            $('.btn-group').removeClass('open');
		        } else {
		            $('.btn-group').addClass('open');
		        }

		
		});
		//카테고리버튼 드롭다운 토글	
		
		
		
		
		
		//mypageauctioninfolist 배송지 입력 버튼 눌렀을때 작동하는 기능
	  	var hiddenMID = $('#hiddenMID').val();
	  	var hiddenANUM = $('#hiddenANUM').val();
   		console.log(hiddenANUM);	

		 //span안에 있는경우는 HTML 
		 
	 $('[id^="deliveryinfobtn"]').click(function() {
        // 새로운 창의 너비와 높이를 지정
       
        var width = 590;
        var height = 200;

        // 화면 중앙에 위치시키기 위한 좌표 계산
        var left = (window.innerWidth - width) / 2;
        var top = (window.innerHeight - height) / 2;




		
        // 새로운 창 열기
        window.open('/sidol1/mypagedeliveryinfo.jsp?M_ID=' + encodeURIComponent(hiddenMID)+'&A_NUM='+ encodeURIComponent(hiddenANUM), '새로운 창', 'width=' + width + ', height=' + height + ', left=' + left + ', top=' + top);
      });

  
   });//end of function