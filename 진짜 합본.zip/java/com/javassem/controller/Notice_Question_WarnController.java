package com.javassem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.javassem.service.Notice_Question_WarnService;
import com.javassem.vo.Auction_warnVO;
import com.javassem.vo.AuctioninfoVO;
import com.javassem.vo.MemberVO;
import com.javassem.vo.NoticeVO;
import com.javassem.vo.QuestionVO;
import com.mysql.cj.Session;

@Controller
public class Notice_Question_WarnController {

	@Autowired
	private Notice_Question_WarnService notice_Question_WarnService;

	/*****************************************************************
	 * 회원 기록에 맞추어 작성한 문의글, 신고글 리스트 만들기
	 * 
	 */

	@RequestMapping(value = "info_Faq.do", params = {"Q_WRITE"})
	private void  Question_Warn_List(QuestionVO Qvo, Auction_warnVO Wvo ,Model model) {
		System.out.println(Qvo.getQ_WRITE() + " 회원의 목록 가져오기");
		model.addAttribute("QuestionList", notice_Question_WarnService.get_Question_List(Qvo));
		Wvo.setW_CUSTOMER(Qvo.getQ_WRITE());
		model.addAttribute("WarnList", notice_Question_WarnService.get_Warn_List(Wvo));
		model.addAttribute("NoticeList",notice_Question_WarnService.main_Notice_All());
	}


	/*****************************************************************
	 * 문의글 작성, 확인, 수정, 삭제
	 * 
	 */

	@RequestMapping("Question_Wit.do")
	private String Question_Wit(QuestionVO vo) {
		System.out.println("전달값 : " + vo.toString());
		notice_Question_WarnService.Question_Wit(vo);

		return "redirect:info_page.do";
	}

	@RequestMapping(value = "info_ck_page.do", params = {"Q_NUM"})
	private void Question_Page(QuestionVO vo, Model model) {
		QuestionVO Result = notice_Question_WarnService.Question_Page(vo);
		System.out.println(Result);
		model.addAttribute("question", Result);
	}

	@RequestMapping("info_edit_Wit.do")
	private void Question_Trans(QuestionVO vo, Model model) {

		System.out.println("전달값 : " + vo.toString());
		model.addAttribute("question", vo);
	}

	@RequestMapping("Question_Update.do")
	private String Question_Update(QuestionVO vo) {
		System.out.println("전달값 : " + vo.toString());
		int result = notice_Question_WarnService.Question_Update(vo);

		if(result == 0) {
			System.out.println("수정 실패");
			return "redirect:info_page.do";
		}else { 
			System.out.println("수정 성공");
			return "redirect:info_page.do";
		}
	}

	@RequestMapping(value = "Question_Delete.do")
	private String Question_Delete(QuestionVO vo) {
		System.out.println(vo.toString());
		notice_Question_WarnService.Question_Delete(vo);
		return "redirect:info_Faq.do";
	}

	/*****************************************************************
	 * 신고글 존재 확인, 작성, 확인
	 * 
	 */

	@RequestMapping(value = "bid_Write.do", params = {"A_NUM", "W_CUSTOMER"})
	private String Warn_Check(Auction_warnVO vo) {
		
		System.out.println(vo.getA_NUM()+""+vo.getW_CUSTOMER());
		
		if (vo.getW_CUSTOMER() == "") {
			System.out.println("로그인 기록 없음 작성불가");
			return "redirect:bid_Pc.do?A_NUM="+vo.getA_NUM()+"&M_ID="+vo.getW_CUSTOMER()+"&ING_BUYER="+vo.getW_CUSTOMER();
		}
		
		int result = notice_Question_WarnService.Warn_Check(vo);

		if (result == 0) {
			System.out.println("작성 이력이 없어 작성가능");
			return "redirect:bid_Warning.do?A_NUM="+vo.getA_NUM()+"&W_CUSTOMER="+vo.getW_CUSTOMER();
		}else {
			System.out.println("작성 이력이 있어 작성불가");
			return "redirect:bid_Pc.do?A_NUM="+vo.getA_NUM()+"&M_ID="+vo.getW_CUSTOMER()+"&ING_BUYER="+vo.getW_CUSTOMER();}
	}

	@RequestMapping(value = "bid_Write2.do", params = {"A_NUM", "W_CUSTOMER"})
	@ResponseBody
	private String Warn_Check2(Auction_warnVO vo) {
		System.out.println(vo.getA_NUM()+""+vo.getW_CUSTOMER());
		
		if (vo.getW_CUSTOMER() == null) {
			System.out.println("로그인 기록 없음 작성불가");
			return "1";
		}
		
		int result = notice_Question_WarnService.Warn_Check(vo);

		if (result == 0) {
			System.out.println("작성 이력이 없어 작성가능");
			return "0";
		}else {
			System.out.println("작성 이력이 있어 작성불가");
			return "1";}
	}

	@RequestMapping("Warn_Wit.do")
	private String Warn_Wit(Auction_warnVO vo) {
		System.out.println("전달값 : " + vo.toString());
		notice_Question_WarnService.Warn_Wit(vo);
		return "redirect:info_page.do";
	}

	@RequestMapping(value = "info_Warn_page.do", params = {"W_CUSTOMER","A_NUM"})
	private void Warn_Page(Auction_warnVO vo, Model model) {
		Auction_warnVO Result = notice_Question_WarnService.Warn_Page(vo);
		System.out.println(Result);
		model.addAttribute("Warn", Result);
	}

	/********************************************************************************
	 * 관리자 페이지 작업들
	 * 
	 */

	@RequestMapping("question_list.do")
	private void main_Question_All(Model model) {
		model.addAttribute("questionList", notice_Question_WarnService.main_Question_All());
	}

	@RequestMapping("warn_list.do")
	private void main_Warn_All(Model model) {
		model.addAttribute("warnList", notice_Question_WarnService.main_Warn_All());
	}
	
	@RequestMapping("notice_list.do")
	private void main_Notice_All(Model model) {
		model.addAttribute("noticeList", notice_Question_WarnService.main_Notice_All());
	}

	// 관리자 문의글 리스트의 항목 번호를 기준으로 해당 문의글 내용 출력 
	@RequestMapping(value = "question_detail.do", params = {"Q_NUM"})
	private void main_Question_Page(QuestionVO vo, Model model) {
		System.out.println(vo.getQ_NUM());
		model.addAttribute("question", notice_Question_WarnService.Question_Page(vo));
	}

	@RequestMapping("main_Question_Update.do")
	private String main_Question_Update(QuestionVO vo) {
		System.out.println("전달값 : " + vo.toString());
		notice_Question_WarnService.main_Question_Update(vo);
		return "redirect:question_list.do";
	}

	// 관리자 신고글 리스트의 항목 번호를 기준으로 해당 문의글 내용 출력 
	@RequestMapping(value = "warn_detail.do", params = {"W_NUM"})
	private void main_Warn_Page(Auction_warnVO vo, Model model) {
		System.out.println(vo.getW_NUM());
		model.addAttribute("warn", notice_Question_WarnService.main_Warn_Page(vo));
	}

	@RequestMapping("main_Warn_Update.do")
	private String main_Warn_Update(Auction_warnVO vo) {
		System.out.println("전달값 : " + vo.toString());
		notice_Question_WarnService.main_Warn_Update(vo);
		return "redirect:warn_list.do";
	}
	
	// 공지글 작성
	@RequestMapping("Notice_Wit.do")
	private String Notice_Wit(NoticeVO vo) {
		System.out.println("전달값 : " + vo.toString());
		notice_Question_WarnService.Notice_Wit(vo);
		return "redirect:notice_list.do";
	}
	
	// 공지글로 이동
	@RequestMapping(value = "info_Ck_Npage.do", params = {"N_NUM"})
	private void Notice_Page(NoticeVO vo, Model model) {
		System.out.println(vo.getN_NUM());
		model.addAttribute("notice", notice_Question_WarnService.Notice_Page(vo));
	}
}
