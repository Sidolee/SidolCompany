package com.javassem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javassem.service.AuctionEndService;
import com.javassem.service.Auction_infoService;
import com.javassem.service.Auction_ingService;
import com.javassem.service.CashService;
import com.javassem.service.StorageService;
import com.javassem.service.WishListService;
import com.javassem.vo.AuctionEndVO;
import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_ingVO;
import com.javassem.vo.AuctioninfoVO;
import com.javassem.vo.CashVO;
import com.javassem.vo.StorageVO;
import com.javassem.vo.WishListVO;

@Controller
public class Auction_infoController {

	@Autowired
	private Auction_infoService auction_infoService;
	
	@Autowired
	private CashService cashservice;
	
	@Autowired
	private Auction_ingService auction_ingService;
	
	// 찜 리스트 서비스
	@Autowired
	private WishListService  wishListService;
	
	// 종료된 경매
	@Autowired
	private AuctionEndService endService;
	
	@Autowired
	private StorageService sService;
	
	

	@RequestMapping(value = "/bid_Pc.do", params = {"A_NUM", "M_ID", "ING_BUYER"})
	private void selectProduct(Auction_infoVO vo,CashVO cashvo, Auction_ingVO ingvo, Model model) {
		
		//getMyAccount로 받은 CashVO cashinfo
		
		
		model.addAttribute("cash",cashservice.getMyAccount(cashvo));
		model.addAttribute("product", auction_infoService.selectByA(vo));
		model.addAttribute("ingproduct",auction_ingService.getAuction_ingInfo(ingvo) );
		model.addAttribute("ingproductmember",auction_ingService.getAuction_ingInfomember(ingvo) );
		// 11.08 이시돌, access 숫자 반영 test
		model.addAttribute("access", auction_ingService.getAccessCount(ingvo));
		// 11.08 정거닐
		model.addAttribute("memberinfo",auction_infoService.getMembervo(vo));
		// 상품 찜 인원 확인
		
				WishListVO wvo = new WishListVO();
				wvo.setW_ID(cashvo.getM_ID());
				wvo.setW_PRODUCT(vo.getA_NUM());
				model.addAttribute("wishcount", wishListService.WishListAllCount(wvo) );
		System.out.println(ingvo.getCOUNT());

		
 	}

	@RequestMapping(value = "/productList.do", params={"C_ID"})
	private void productList(Auction_infoVO vo, Model model) {
		System.out.println("카테고리에 따라 값 가져오기");
		System.out.println(auction_infoService.selectByC(vo));
		model.addAttribute("productList", auction_infoService.selectByC(vo));
	}

	@RequestMapping("/searchItem.do")
	public String searchItem(AuctioninfoVO vo, Model model) {
		System.out.println("1. [searchItem.do](http://searchitem.do/) 요청 수락");
		
		List<AuctioninfoVO> result = auction_infoService.searchItem(vo);
		
		System.out.println(result);
		model.addAttribute("productList", result);
		// 한줄만 추가해서 돌려써보자 제발 -> 안되네
		System.out.println("4. [searchItem.do](http://searchitem.do/) 종료");
		return "productList";
	}
	@RequestMapping("/searchItemByAdmin.do")
	public String searchItemByAdmin(AuctioninfoVO vo, Model model) {
		List<AuctioninfoVO> result = auction_infoService.searchItem(vo);

		model.addAttribute("allAuctions", result);
		// 한줄만 추가해서 돌려써보자 제발 -> 안되네
		System.out.println("4. [searchItem.do](http://searchitem.do/) 종료");
		return "auction_list";
	}	
	
	
	/**************************************************************************
	 * 찜 추가 기능
	 */
	@RequestMapping(value = "/addWishList.do", params = {"W_PRODUCT", "W_ID"})
	@ResponseBody
	private String addWishList(WishListVO vo) {
		System.out.println(vo.toString());
		
		int result = wishListService.WishListCk(vo);
		
		if (result == 0) {
			wishListService.NewWishList(vo);
			return "0";
		}else {
			return "1";
		}
	}
	
	// 메소드명 : getAllAuctions
	// 역할 : 모든 경매 상품을 불러옴 (A_CONDITION 과 무관)
	@RequestMapping("/auction_list.do")
	public String getAllAuctions(Auction_infoVO vo, Model model) {
		System.out.println("1. 컨트롤러에서 getAllAuctions.do 요청 수락");
		
		List<Auction_infoVO> result = auction_infoService.getAllAuctions(vo);
		
		model.addAttribute("allAuctions", result);
		
		return "auction_list";
	}
	
	// 아래에 있는 친구들, 파라미터 값에 따라서 다른 곳으로 보내고 싶은데 그게 ,,, 잘 ,,, 안되네요 ,,
	// 걍 멍청이 코딩함 ,,, ㅅㄱ
	
	// 메소드명 : getAuctions1
	// 역할 : 상품의 유통 단계에 따른 검색결과 출력
	@RequestMapping("/getAuctions1.do")
	public String getAuctions1(Auction_infoVO vo, Model model) {
		System.out.println("1. 컨트롤러에서 검토 미완료 검색 요청 수락");
		List<Auction_infoVO> result = auction_infoService.getAuctions1(vo);
		model.addAttribute("allAuctions", result);
		return "auction_list";
		
	}

	// 메소드명 : getAuctions2
	// 역할 : 상품의 유통 단계에 따른 검색결과 출력
	@RequestMapping("/getAuctions2.do")
	public String getAuctions2(Auction_infoVO vo, Model model) {
		System.out.println("1. 컨트롤러에서 경매 예정 검색 요청 수락");
		List<Auction_infoVO> result = auction_infoService.getAuctions2(vo);
		model.addAttribute("allAuctions", result);
		return "auction_list";
		
	}
	
	// 메소드명 : getAuctions3
	// 역할 : 상품의 유통 단계에 따른 검색결과 출력
	@RequestMapping("/getAuctions3.do")
	public String getAuctions3(Auction_infoVO vo, Model model) {
		System.out.println("1. 컨트롤러에서 경매 진행중 검색 요청 수락");
		List<Auction_infoVO> result = auction_infoService.getAuctions3(vo);
		model.addAttribute("allAuctions", result);
		return "auction_list";
		
	}
	
	// 메소드명 : getAuctions4
	// 역할 : 상품의 유통 단계에 따른 검색결과 출력
	@RequestMapping("/getAuctions4.do")
	public String getAuctions4(Auction_infoVO vo, Model model) {
		System.out.println("1. 컨트롤러에서 경매 완료 검색 요청 수락");
		List<Auction_infoVO> result = auction_infoService.getAuctions4(vo);
		model.addAttribute("allAuctions", result);
		return "auction_list";
		
	}
	//11.08 17:47분 추가됨
	//메소드명 : getAuctionsinfo
	//역할 : 경매리스트정보불러오기
	// ********************* 찜한 인원 불러오기 대 실 패 .
	@RequestMapping(value = "/auction_list2.do", params = {"A_NUM","M_ID"})
	public void getAuctionsinfo(Auction_infoVO vo, Auction_ingVO ingvo ,AuctionEndVO endvo, StorageVO svo, WishListVO wvo, Model model) {
		model.addAttribute("product", auction_infoService.selectByA(vo));
		System.out.println("1--------------------------------------------");
		model.addAttribute("memberinfo",auction_infoService.getMembervo(vo));
		System.out.println("2--------------------------------------------");
		// 상품 보관위치 불러오기 추가
		model.addAttribute("storage", sService.getInfo(svo));
		System.out.println("3--------------------------------------------");
		// 상품의 최고가와 그걸 부른 사람
		model.addAttribute("ing", auction_ingService.getAuction_ingInfo(ingvo)); // 
		System.out.println("4--------------------------------------------");
		// 상품 찜한 인원 불러오기
		model.addAttribute("wish", wishListService.WishListAllCount(wvo));
		System.out.println("5-----------------------------------------");
		// 11.09 : 여기에 다른 테이블 정보 불러오는 것들도 추가
		System.out.println("info a_condition 으로 테스트-------------");
		System.out.println("A_CONDITION : " +   vo.getA_CONDITION());
		if(vo.getA_CONDITION().equals("경매완료") | vo.getA_CONDITION().equals("발송완료")) {
			System.out.println("경매완료의 경우로 들어왔는가");
			model.addAttribute("endInfo", endService.getInfo(vo));
			System.out.println("6--------------------------------------------");
		}


	}
	
	@RequestMapping(value = "/endAuctionByDate.do", params = {"A_NUM"})
	@ResponseBody
	private String endAuctionByDate(Auction_infoVO vo, Auction_ingVO ingvo, AuctionEndVO endvo) {
		System.out.println(vo.getA_NUM() + " " + ingvo.getA_NUM());
		System.out.println("컨디션 작업 - "+ auction_infoService.updateConditionByNum(vo));
		System.out.println("가장 높은 호가 불러오기");
		Auction_ingVO result = auction_ingService.getAuction_ingInfo(ingvo);
		
		if( result.getING_BUYER() == "아직 없음") {
			result.setING_BUYER("admin1");
			System.out.println(result.toString());
		}
		
		System.out.println("End 입력 작업 - "+ endService.auctionEndByTime(result));
		System.out.println(result.getING_BUYER()+"님 구매!");
		
		return "";
	}
	
	// 이벤트 컬럼 찾기 연결
	@RequestMapping(value = "/event_list.do", params={"C_ID"})
	private void eve_productList(Auction_infoVO vo, Model model) {
		System.out.println("이벤트 경매 " +vo.getC_ID()+ "가져오기");
		model.addAttribute("productList", auction_infoService.selectByC(vo));
	}

}
