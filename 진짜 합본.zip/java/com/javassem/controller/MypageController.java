package com.javassem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javassem.service.Auction_infoService;
import com.javassem.service.Auction_ingService;
import com.javassem.service.CashService;
import com.javassem.service.MypageService;
import com.javassem.service.WishListService;
import com.javassem.vo.Auction_EndVO;
import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_ingVO;
import com.javassem.vo.CashVO;
import com.javassem.vo.MypageauctionlistVO;
import com.javassem.vo.WishListVO;

@Controller
public class MypageController {

	@Autowired
	private MypageService mypageService;

	@Autowired
	private CashService cashservice;

	@Autowired
	private Auction_infoService auction_infoService;

	@Autowired
	private Auction_ingService auction_ingService;

	@Autowired
	private WishListService wishlistservice;

	
	// 낙찰받은 경매리스트 불러오기
	@RequestMapping(value = "/mypageauctionlist.do", params = { "M_ID", "END_BUYER" })
	public void getauctionendinfo(Auction_EndVO endvo, Auction_infoVO vo, Model model) {

		System.out.println("Auction_EndVO의 BUYER값 : " + endvo.getEND_BUYER());

		List<MypageauctionlistVO> result = mypageService.getMypageauctionlist(endvo);
		model.addAttribute("endinfo", result);

		System.out.println("Auction_EndVO의 BUYER값 : " + result);

	}
	
	//낙찰받은 경매리스트 검색기능
	@RequestMapping("/mypageauctionlistsearch.do")
	public String searchItem(Auction_EndVO vo, Model model) {
		System.out.println("searchItem 의 값 : " + vo.toString());

		List<MypageauctionlistVO> result = mypageService.mypageauctionlistsearch(vo);
		
		System.out.println(result);
		model.addAttribute("endinfo", result);
		

		return "mypageauctionlist";
	}

	// 참여했던 경매의 리스트 불러오기
	  @RequestMapping(value = "/mypageauctionpro.do", params = {"M_ID","ING_BUYER"}) 
	  public void getauctioninginfo(Auction_ingVO ingvo,Auction_infoVO vo, Model model) {
	  
		  System.out.println("Getauctioninginfo의 BUYER값 : " + ingvo.getING_BUYER());

		 List<Auction_infoVO> result = mypageService.getMypageauctioninglist(ingvo);
	  model.addAttribute("auctioninginfo",result);
	  
	  
	  
	 }
	 
		//찜 목록 리스트 불러오기
	@RequestMapping(value = "/mypagewishlist.do", params = { "W_ID" })
	public void getWishlist(WishListVO wishvo, Model model) {

		System.out.println("mypagewishlist ==> WishListVO의 W_ID값 : " + wishvo.getW_ID());
		model.addAttribute("wishinfo", mypageService.getWishlist(wishvo));

	}

	//찜 목록 삭제하기.
	@RequestMapping(value = "/deletewishlist.do", params = { "W_ID", "W_PRODUCT" })
	@ResponseBody
	public String deleteWishlist(WishListVO wishvo) {

		System.out.println("WishListVO의 W_ID값 : " + wishvo.getW_ID());
		System.out.println("WishListVO의 W_PRODUCT값 : " + wishvo.getW_PRODUCT());
		mypageService.deleteWishlist(wishvo);

		return "";

	}
	
	
		//배송 리스트 불러오기
	@RequestMapping(value = "/mypagedelivery.do", params = { "END_BUYER" })
	public void getDeliverylist(Auction_EndVO endvo, Model model) {

		System.out.println("Auction_EndVO의 END_BUYER값 : " + endvo.getEND_BUYER());

		
		model.addAttribute("deliverylist",mypageService.getDeliverylist(endvo));
		System.out.println("WishListVO의 W_ID값 : " + mypageService.getDeliverylist(endvo).toString());

	}
	
	
	
	//DELIVERY_ADDR/END_BUYER/DELIVERY_COMPANY/DELIVERY_NUM
	//배송지 입력하기 >__<
	@RequestMapping("/deliverymodify.do")
	public String mypagedeliverymodify(Auction_EndVO endvo,Model model) {

		System.out.println("mypagedeliverymodify ==> mypagedeliverymodify의 Auction_EndVO값 : " + endvo.toString());
		 mypageService.mypagedeliverymodify(endvo);
		 model.addAttribute("closeWindow", true);
		  return "mypagedeliveryinfo";
	}
	
	
	// [ 위시리스트 => bid_PC 로 넘어가는 컨트롤러 ]화면이 안넘어가져요..
	@RequestMapping(value = "/goingbid_Pc.do", params = { "A_NUM", "M_ID", "ING_BUYER" })
	@ResponseBody
	public String goingbidPc(Auction_infoVO vo, CashVO cashvo, Auction_ingVO ingvo, Model model) {

		System.out.println("goingbid_Pc까지는 왔나요.... " + vo.getA_NUM() + "/" + ingvo.getA_NUM() + "/" + cashvo.getM_ID());
		model.addAttribute("cash", cashservice.getMyAccount(cashvo));
		model.addAttribute("product", auction_infoService.selectByA(vo));
		model.addAttribute("ingproduct", auction_ingService.getAuction_ingInfo(ingvo));
		model.addAttribute("ingproductmember", auction_ingService.getAuction_ingInfomember(ingvo));
		// 11.08 이시돌, access 숫자 반영 test
		model.addAttribute("access", auction_ingService.getAccessCount(ingvo));
		// 11.08 정거닐
		model.addAttribute("memberinfo", auction_infoService.getMembervo(vo));
		// 상품 찜 인원 확인

		WishListVO wvo = new WishListVO();
		wvo.setW_ID(cashvo.getM_ID());
		wvo.setW_PRODUCT(vo.getA_NUM());
		model.addAttribute("wishcount", wishlistservice.WishListAllCount(wvo));
		System.out.println(ingvo.getCOUNT());

		return "redirect:/bid_Pc.do";

	}

}
