package com.javassem.dao;

import com.javassem.vo.CategoryVO;

public interface CategoryDAO {
	public CategoryVO getCategory(CategoryVO vo);
}
