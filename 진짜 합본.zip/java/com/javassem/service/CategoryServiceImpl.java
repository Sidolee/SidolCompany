package com.javassem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.CategoryDAO;
import com.javassem.vo.CategoryVO;
@Service
public class CategoryServiceImpl implements CategoryService{

	@Autowired
	private CategoryDAO caDAO;
	
	@Override
	public CategoryVO getCategory(CategoryVO vo) {
		System.out.println("2. service : dao 에 getCategory 요청");
		return caDAO.getCategory(vo);
	}

}
