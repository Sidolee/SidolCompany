package com.javassem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.Notice_Question_WarnDAO;
import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_warnVO;
import com.javassem.vo.MemberVO;
import com.javassem.vo.NoticeVO;
import com.javassem.vo.QuestionVO;

@Service
public class Notice_Question_WarnServiceImpl implements Notice_Question_WarnService{
	
	@Autowired
	private Notice_Question_WarnDAO notice_Question_WarnDAO;

	@Override
	public void Question_Wit(QuestionVO vo) {
		notice_Question_WarnDAO.Question_Wit(vo);
	}

	@Override
	public QuestionVO Question_Page(QuestionVO vo) {
		return notice_Question_WarnDAO.Question_Page(vo);
	}

	@Override
	public int Question_Update(QuestionVO vo) {
		return notice_Question_WarnDAO.Question_Update(vo);
	}
	
	@Override
	public void Question_Delete(QuestionVO vo) {
		notice_Question_WarnDAO.Question_Delete(vo);
	}

	@Override
	public int Warn_Check(Auction_warnVO vo) {
		return notice_Question_WarnDAO.Warn_Check(vo);
	}
	
	@Override
	public void Warn_Wit(Auction_warnVO vo) {
		notice_Question_WarnDAO.Warn_Wit(vo);
	}

	@Override
	public Auction_warnVO Warn_Page(Auction_warnVO vo) {
		return notice_Question_WarnDAO.Warn_Page(vo);
	}

	@Override
	public List<QuestionVO> get_Question_List(QuestionVO vo) {
		System.out.println(vo.getQ_WRITE());
		return notice_Question_WarnDAO.get_Question_List(vo);
	}

	@Override
	public List<Auction_warnVO> get_Warn_List(Auction_warnVO vo) {
		System.out.println(vo.getW_CUSTOMER());
		return notice_Question_WarnDAO.get_Warn_List(vo);
	}

	@Override
	public List<QuestionVO> main_Question_All() {
		return notice_Question_WarnDAO.main_Question_All();
	}

	@Override
	public void main_Question_Update(QuestionVO vo) {
		notice_Question_WarnDAO.main_Question_Update(vo);
	}

	@Override
	public List<Auction_warnVO> main_Warn_All() {
		return notice_Question_WarnDAO.main_Warn_All();
	}

	@Override
	public Auction_warnVO main_Warn_Page(Auction_warnVO vo) {
		return notice_Question_WarnDAO.main_Warn_Page(vo);
	}

	@Override
	public void main_Warn_Update(Auction_warnVO vo) {
		notice_Question_WarnDAO.main_Warn_Update(vo);
	}

	@Override
	public List<NoticeVO> main_Notice_All() {
		return notice_Question_WarnDAO.main_Notice_All();
	}

	@Override
	public void Notice_Wit(NoticeVO vo) {
		notice_Question_WarnDAO.Notice_Wit(vo);
	}

	@Override
	public NoticeVO Notice_Page(NoticeVO vo) {
		return notice_Question_WarnDAO.Notice_Page(vo);
	}


}
