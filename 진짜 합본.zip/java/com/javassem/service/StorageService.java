package com.javassem.service;

import com.javassem.vo.StorageVO;

public interface StorageService {
	public StorageVO getInfo(StorageVO vo);
}
