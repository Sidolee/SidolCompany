package com.javassem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.StorageDAO;
import com.javassem.vo.StorageVO;

@Service
public class StorageServiceImpl implements StorageService{
	@Autowired
	StorageDAO dao;

	@Override
	public StorageVO getInfo(StorageVO svo) {
		return dao.getInfo(svo);
	}
}
