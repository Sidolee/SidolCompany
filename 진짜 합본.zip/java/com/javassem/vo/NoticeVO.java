package com.javassem.vo;

import java.util.Date;

import lombok.Data;

@Data
public class NoticeVO {
	
	private Integer N_NUM;				// 공지번호
	private String N_TITLE;			// 제목
	private Date N_DATE;			// 등록날짜
	private String N_CONTENT;		// 내용
	private String M_ID;			// 아이디
	
	/*
	`N_NUM`     INT          NOT NULL COMMENT '', -- 공지번호
	`N_TITLE`   VARCHAR(30)  NULL     COMMENT '', -- 제목
	`N_DATE`    DATE         NULL     COMMENT '', -- 등록날짜
	`N_CONTENT` VARCHAR(255) NULL     COMMENT '', -- 내용
	`N_IMG`     VARCHAR(100) NULL     COMMENT '', -- 이미지
	`M_ID`      VARCHAR(20)  NULL     COMMENT '' -- 아이디
*/
	
}
