package com.javassem.vo;

public class MypageDeliverylistVO {
	private Integer END_COST ;
	private String A_REALIMG ;
	private String A_TITLE ;
	private Integer A_NUM ;
	private String A_CONDITION;
	public Integer getEND_COST() {
		return END_COST;
	}
	public void setEND_COST(Integer eND_COST) {
		END_COST = eND_COST;
	}
	public String getA_REALIMG() {
		return A_REALIMG;
	}
	public void setA_REALIMG(String a_REALIMG) {
		A_REALIMG = a_REALIMG;
	}
	public String getA_TITLE() {
		return A_TITLE;
	}
	public void setA_TITLE(String a_TITLE) {
		A_TITLE = a_TITLE;
	}
	public Integer getA_NUM() {
		return A_NUM;
	}
	public void setA_NUM(Integer a_NUM) {
		A_NUM = a_NUM;
	}
	public String getA_CONDITION() {
		return A_CONDITION;
	}
	public void setA_CONDITION(String a_CONDITION) {
		A_CONDITION = a_CONDITION;
	}
	
	

}
