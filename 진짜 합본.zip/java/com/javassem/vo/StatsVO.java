package com.javassem.vo;

import lombok.Data;

@Data
public class StatsVO {
	private Integer totalCost;
	private Integer ingCount;
	private Integer endCount;
	private Integer todayAccess;
	private Integer unRepliedQuestion;
	private Integer unProcessedWarn;
	private Integer logDate;
	private Integer logCount;
	private Integer maleCnt;
	private Integer femaleCnt;
	private Integer maleCost;
	private Integer femaleCost;
	private Integer under20;
	private Integer under40;
	private Integer under60;
	private Integer over60;
	private Integer totalToday;

}
