$(function(){
	
	var time = $("#count").val();
	
	time = time ; //- 43200000;
	
	var date = new Date();
	
	setInterval(function(){
	
	time = time - 1000;
	
	date.setTime(time);
	
	$("#time").text(((date.getHours()*1) <= 9 ? "0" + date.getHours() : date.getHours())+":"
		+((date.getMinutes()*1) <= 9 ? "0" + date.getMinutes() : date.getMinutes())+":"
		+((date.getSeconds()+1) < 9 ? "0" + date.getSeconds() : date.getSeconds()));
			
	}, 1000);
		
});