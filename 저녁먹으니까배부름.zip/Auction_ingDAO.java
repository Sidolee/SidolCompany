package com.javassem.dao;

import com.javassem.vo.Auction_ingVO;

public interface Auction_ingDAO {
	public void joinAuction(Auction_ingVO vo);
}
