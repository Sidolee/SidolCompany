package com.javassem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.StatsDAO;

@Service
public class StatsServiceImpl implements StatsService{
	@Autowired
	private StatsDAO sDAO;

	@Override
	public Integer getTodayTotalCost() {
		return sDAO.getTodayTotalCost();
	}

	@Override
	public Integer getTodayIngCount() {
		return sDAO.getTodayIngCount();
	}

	@Override
	public Integer getTodayEndCount() {
		return sDAO.getTodayEndCount();
	}

	@Override
	public Integer getTodayAccess() {
		return sDAO.getTodayAccess();
	}

	@Override
	public Integer getUnrepliedQuestion() {
		return sDAO.getUnrepliedQuestion();
	}

	@Override
	public Integer getUnProcessedWarn() {
		return sDAO.getUnProcessedWarn();
	}
	
	
}
