package com.javassem.vo;

import java.util.Date;

import lombok.Data;

@Data
public class Auction_ingVO {
	
	private String A_NUM;
	private String ING_BUYER;
	private Integer ING_COST;
	private Date TIME_COST;
}
