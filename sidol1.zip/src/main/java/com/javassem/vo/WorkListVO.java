package com.javassem.vo;

import java.util.Date;

import lombok.Data;

@Data
public class WorkListVO {
	
	private String WORK_ID;
	private String WORK_CATEGORY;
	private String WORK_THING;
	private String WORK_TIME;
	private String WORK_MEMO;

}
