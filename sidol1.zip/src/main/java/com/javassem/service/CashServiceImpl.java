package com.javassem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.CashDAO;
import com.javassem.vo.CashVO;
@Service
public class CashServiceImpl implements CashService{

	
	@Autowired
	private CashDAO cashDAO;
	
	@Override
	public void updateAccount(CashVO vo) {
		System.out.println("CashServiceImpl : updateAccount() 호출");
		cashDAO.updateAccount(vo);
		
	}

	@Override
	public CashVO getMyAccount(CashVO vo) {
		return cashDAO.getMyAccount(vo);
	}

	@Override
	public void chargeAccount(CashVO vo) {
		System.out.println("CashServiceImpl : chargeAccount() 호출");
		cashDAO.chargeAccount(vo);
		
	}

}
