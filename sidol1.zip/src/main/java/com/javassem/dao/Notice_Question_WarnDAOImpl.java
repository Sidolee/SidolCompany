package com.javassem.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_warnVO;
import com.javassem.vo.MemberVO;
import com.javassem.vo.QuestionVO;

@Repository
public class Notice_Question_WarnDAOImpl implements Notice_Question_WarnDAO{

	@Autowired
	private SqlSessionTemplate mybatis;

	@Override
	public void Question_Wit(QuestionVO vo) {
		System.out.println("insertQuestion 작업");
		int result = mybatis.insert("question.insertQuestion", vo);
		System.out.println(result);
	}

	@Override
	public QuestionVO Question_Page(QuestionVO vo) {
		System.out.println("selectQuestionByNum 작업");
		return mybatis.selectOne("question.selectQuestionByNum", vo);
	}
	
	@Override
	public int Question_Update(QuestionVO vo) {
		System.out.println("updateQuestionByNumPw 작업");
		return mybatis.update("question.updateQuestionByNumPw", vo);
	}

	@Override
	public void Question_Delete(QuestionVO vo) {
		System.out.println("deleteQuestion 작업");
		int result = mybatis.delete("question.deleteQuestionByNumPw", vo);
		System.out.println(result);
	}
	
	@Override
	public int Warn_Check(Auction_warnVO vo) {
		System.out.println("Warn_Check 작업");
		if (mybatis.selectOne("auction_warn.selectByIdNum", vo) != null) {
			return 1;
		}else return 0;
	}
	
	@Override
	public void Warn_Wit(Auction_warnVO vo) {
		System.out.println("insertWarn 작업");
		int result = mybatis.insert("auction_warn.insertWarn", vo);
		Auction_infoVO avo = new Auction_infoVO();
		avo.setA_NUM(vo.getA_NUM());
		mybatis.update("auction_info.updateWarn", avo);
		System.out.println(result);
	}

	@Override
	public Auction_warnVO Warn_Page(Auction_warnVO vo) {
		System.out.println("selectWarn 작업");
		return mybatis.selectOne("auction_warn.selectByIdNum", vo);
	}

	@Override
	public List<QuestionVO> get_Question_List(QuestionVO vo) {
		System.out.println("selectListQuestionById 작업");
		System.out.println(vo.getQ_WRITE());
		return mybatis.selectList("question.selectListQuestionById", vo);
	}

	@Override
	public List<Auction_warnVO> get_Warn_List(Auction_warnVO vo) {
		System.out.println("selectListQuestionById 작업");
		System.out.println(vo.getW_CUSTOMER());
		return mybatis.selectList("auction_warn.selectById", vo);
	}

	@Override
	public List<QuestionVO> main_Question_All() {
		System.out.println("selectListQuestionById 작업");
		System.out.println(mybatis.selectList("question.selectQuestionAllFi"));
		return mybatis.selectList("question.selectQuestionAllFi");
	}

	@Override
	public void main_Question_Update(QuestionVO vo) {
		System.out.println("updateQuestionByMain 작업");
		int result = mybatis.update("question.updateQuestionByMain", vo);
		System.out.println(result);
	}


}
