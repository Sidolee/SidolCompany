package com.javassem.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.WorkListVO;

@Repository
public class WorkListDAOImpl implements WorkListDAO {
	
	@Autowired
	private SqlSessionTemplate mybatis;

	@Override
	public List<WorkListVO> getWorkList(WorkListVO vo) {
		System.out.println("3. WorkListDAOImpl : getWorkList() 호출");
		
		return mybatis.selectList("member.getWorkList", vo);
		
	}

	@Override
	public void insertWorkList(WorkListVO vo) {
		System.out.println("3. WorkListDAOImpl : insertWorkList() 호출");
		mybatis.insert("member.insertWorkList", vo);
		
	}

}
