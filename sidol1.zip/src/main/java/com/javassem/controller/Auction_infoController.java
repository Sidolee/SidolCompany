package com.javassem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javassem.service.Auction_infoService;
import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.AuctioninfoVO;

@Controller
public class Auction_infoController {

	@Autowired
	private Auction_infoService auction_infoService;

	@RequestMapping(value = "/bid_Pc.do", params = {"A_NUM"})
	private void selectProduct(Auction_infoVO vo, Model model) {
		System.out.println("상품 경매 가져오기");
		model.addAttribute("product", auction_infoService.selectByA(vo));
	}

	@RequestMapping(value = "/productList.do", params={"C_ID"})
	private void productList(Auction_infoVO vo, Model model) {
		System.out.println("카테고리에 따라 값 가져오기");
		model.addAttribute("productList", auction_infoService.selectByC(vo));
	}

	@RequestMapping("/searchItem.do")
	public String searchItem(AuctioninfoVO vo, Model model) {
		System.out.println("1. [searchItem.do](http://searchitem.do/) 요청 수락");
		
		List<AuctioninfoVO> result = auction_infoService.searchItem(vo);
		
		System.out.println(result);
		model.addAttribute("productList", result);
		System.out.println("4. [searchItem.do](http://searchitem.do/) 종료");
		return "productList";
	}

}
