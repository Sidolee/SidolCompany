package com.javassem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javassem.service.MemberService;
import com.javassem.vo.MemberVO;

@Controller
public class MemberController {
	
	@Autowired
	private MemberService memberService;
	
	@RequestMapping("/insertMember.do")
	public String insertMember(MemberVO vo) {
		System.out.println("insertMember.do 요청 수령");
		System.out.println(vo.toString());
		memberService.insertMember(vo); 
		return "redirect:main_login"; // 이게 안가져요 ㅠㅠ
	}
	
	@RequestMapping("/selectAllMember.do")
	public void selectAllMember(MemberVO vo, Model model) {
		System.out.println("selectAllMember.do 요청 수령");
		System.out.println(vo.toString());
		model.addAttribute("memberList", memberService.selectAllMember(vo));
	}

	@RequestMapping("/{step}.do")
	public String viewPage(@PathVariable String step) {
		return step;
	}
	
}
