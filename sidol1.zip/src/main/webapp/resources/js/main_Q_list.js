$(function(){

	$("#ajaxck").click(function(){ 
		//alert("ajax 확인");
		$.ajax ({
			type : 'post',
			data : {temp : 'ok'},
			url : '/sidol1/test.do',
			success : function(result){ 
				//alert(result);
				console.log("a"+result);
			},
			error : function(err){ }
		});
		
	});	
	
});