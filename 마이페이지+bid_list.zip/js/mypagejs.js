/**
 * 
 */
 
  $(function(){
    		
  
  	//찜 리스트 삭제
  	 	$('[id^="deletebtn"]').click(function(){
  		
  		var index = $(this).attr('id').replace('deletebtn', '');
        var W_PRODUCT = $('#getNum' + index).val();
        var W_ID = $('#getId' + index).val();
   	
  			
  			$.ajax({
 			type	: 'get',
 			data	: {W_ID  , W_PRODUCT},
 			url		: '/sidol1/deletewishlist.do',
 			success	: function(){
 							alert("찜목록에서 삭제되었습니다.");
 							
 							 
 			 },
 			error	: function(err){alert('작업 그 자체의 실패');}
 		
 		}); // end of 	ajax
 		
 		
 		
  	
  		}); // end of 찜 리스트 삭제
  		
  		
  		$('[id^="joinauctionbtn"]').click(function(){
  		
  		var index = $(this).attr('id').replace('joinauctionbtn', '');
        var A_NUM = $('#getNum' + index).val();
        var ING_BUYER = $('#getId' + index).val();
   	    var M_ID = $('#getId' + index).val();
   	
   	
  			
  			$.ajax({
 			type	: 'get',
 			data	: {A_NUM, ING_BUYER, M_ID},
 			url		: '/sidol1/goingbid_Pc.do',
 			success	: function(response){
 							
 						 //console.log("Redirected to: " + response);	
 							 //window.location.href = response;
 			 },
 			error	: function(err){alert('작업 그 자체의 실패');}
 		
 		}); // end of ajax
 		
 		
 		
  	
  		}); // end of 회원가입-아이디 중복확인
  		
  		
  		
	
		$('#categorybtn').click(function(){
		
			  var isOpen = $('.btn-group').hasClass('open');

		        // Remove 'active' class from all links
		        if (isOpen) {
		            $('.btn-group').removeClass('open');
		        } else {
		            $('.btn-group').addClass('open');
		        }

		
		});
		
		


  
   });