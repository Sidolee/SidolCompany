package com.javassem.service;

import java.util.List;

import com.javassem.vo.Auction_EndVO;
import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.Auction_ingVO;
import com.javassem.vo.MypageDeliverylistVO;
import com.javassem.vo.MypageauctionlistVO;
import com.javassem.vo.MypagewishlistVO;
import com.javassem.vo.WishListVO;

public interface MypageService {
	// 낙찰받은 경매리스트 불러오기
	public List<MypageauctionlistVO> getMypageauctionlist(Auction_EndVO endvo);
	
	// 참여했던 경매의 리스트 불러오기
	public List<Auction_infoVO> getMypageauctioninglist(Auction_ingVO ingvo);
	
	//찜 목록 리스트 불러오기
	public List<MypagewishlistVO> getWishlist(WishListVO vo);
	
	//찜 목록 삭제하기.
	public void deleteWishlist(WishListVO vo);
	
	//배송 목록 불러오기
	public List<MypageDeliverylistVO> getDeliverylist(Auction_EndVO endvo);

}
