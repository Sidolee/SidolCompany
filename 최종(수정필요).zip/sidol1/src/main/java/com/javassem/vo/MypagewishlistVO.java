package com.javassem.vo;

import java.sql.Date;

public class MypagewishlistVO {
	
	private String A_TITLE;
	private Date A_ENDDAY;
	private Integer START_COST;
	private Integer A_NUM;
	private String A_REALIMG;
	
	
	public Integer getSTART_COST() {
		return START_COST;
	}
	public void setSTART_COST(Integer sTART_COST) {
		START_COST = sTART_COST;
	}
	public String getA_TITLE() {
		return A_TITLE;
	}
	public void setA_TITLE(String a_TITLE) {
		A_TITLE = a_TITLE;
	}
	public Date getA_ENDDAY() {
		return A_ENDDAY;
	}
	public void setA_ENDDAY(Date a_ENDDAY) {
		A_ENDDAY = a_ENDDAY;
	}

	public String getA_REALIMG() {
		return A_REALIMG;
	}
	public void setA_REALIMG(String a_REALIMG) {
		A_REALIMG = a_REALIMG;
	}

	public Integer getA_NUM() {
		return A_NUM;
	}
	public void setA_NUM(Integer a_NUM) {
		A_NUM = a_NUM;
	}

	
	
}
