package com.javassem.vo;

import lombok.Data;

@Data
public class StatsVO {
	private Integer totalCost;
	private Integer ingCount;
	private Integer endCount;
}
