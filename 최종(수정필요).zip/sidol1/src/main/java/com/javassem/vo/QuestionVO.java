package com.javassem.vo;

import java.util.Date;

import lombok.Data;

@Data
public class QuestionVO {
	
	private int Q_NUM;				// 글번호(자동증가)
	
	private String Q_WRITE;			// 아이디(고객)
	private String Q_TITLE;			// 문의글 제목
	private Date Q_DATE;			// 등록날짜
	private String Q_CONTENT;		// 내용
	private String Q_PW;			// 비밀번호 - 고객 비번?
	
	private String Q_R_CONTENT;		// 답변내용
	private Date Q_R_DATE;			// 답변 날짜
	private String Q_REPLY;			// 아이디(답변)
	
	private String Q_CATEGORY;    	// 문의글 분류
	
}
