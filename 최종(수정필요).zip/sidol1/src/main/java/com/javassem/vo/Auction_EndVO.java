package com.javassem.vo;

import java.util.Date;

import lombok.Data;

@Data
public class Auction_EndVO {
	private Integer END_COST;
	private String DELIVERY_ADDR;
	private String DELIVERY_COMPANY;
	private String DELIVERY_NUM;
	private Date DELIVERY_DATE;
	private Integer A_NUM;
	private String END_BUYER;
}
