package com.javassem.vo;

import lombok.Data;

@Data
public class CategoryVO {
	
	private Integer C_ID;
	private String C_NAME;
	private String M_ID;

}
