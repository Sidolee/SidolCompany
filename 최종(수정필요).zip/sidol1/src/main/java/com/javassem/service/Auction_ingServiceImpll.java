package com.javassem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.Auction_ingDAO;
import com.javassem.vo.Auction_ingVO;
@Service
public class Auction_ingServiceImpll implements Auction_ingService{

	@Autowired
	private Auction_ingDAO ingDAO;
	
	@Override
	public void joinAuction(Auction_ingVO vo) {
		System.out.println("2. ingService => joinAuction() 시작");
		ingDAO.joinAuction(vo);
		
	}

	@Override
	public Auction_ingVO getAuction_ingInfo(Auction_ingVO ingvo) {
		return ingDAO.getAuction_ingInfo(ingvo);
		
	}

	@Override
	public Auction_ingVO getAuction_ingInfomember(Auction_ingVO ingvo) {
		// TODO Auto-generated method stub
		return ingDAO.getAuction_ingInfomember(ingvo);
	}

	@Override
	public Auction_ingVO getAccessCount(Auction_ingVO ingvo) {
		return ingDAO.getAccessCount(ingvo);
	}

	@Override
	public void auctionEnd(Auction_ingVO ingvo) {
		ingDAO.auctionEnd(ingvo);
	}

}
