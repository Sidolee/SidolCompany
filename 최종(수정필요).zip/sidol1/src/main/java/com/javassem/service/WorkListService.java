package com.javassem.service;

import java.util.List;

import com.javassem.vo.WorkListVO;

public interface WorkListService {
	
	// worklist 페이지 들어가기 전 worklist 불러오는 칭긔
	List<WorkListVO> getWorkList(WorkListVO vo);
	
	// workList 페이지에서 작업기록 추가
	void insertWorkList(WorkListVO vo);
	
}
