package com.javassem.dao;

import java.util.Date;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.AuctionEndVO;
import com.javassem.vo.Auction_infoVO;

@Repository 
public class AuctionEndDAOImpl implements AuctionEndDAO{

	@Autowired
	private SqlSessionTemplate sql;
	
	
	@Override
	public AuctionEndVO getInfo(Auction_infoVO info) {
		System.out.println("3. member.getInfo sql 요청");
		System.out.println("info에 뭘 담았길래 : " + info.toString());
		AuctionEndVO result = sql.selectOne("member.getInfo", info);
		System.out.println("end에서의 getInfo : " + result);
		
		
			return sql.selectOne("member.getInfo", info);
		
	}

	@Override
	public void updateDeliveryInfo(AuctionEndVO endvo) {
		System.out.println("member.updateDeliveryInfo 요청");
		int result = sql.update("member.updateDeliveryInfo", endvo);
		System.out.println("실행결과 : " + result);
	}
}
