package com.javassem.dao;

public interface StatsDAO {
	
	public Integer getTodayTotalCost();
	public Integer getTodayIngCount();
	public Integer getTodayEndCount();
}
