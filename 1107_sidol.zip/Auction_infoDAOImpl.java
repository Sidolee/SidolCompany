package com.javassem.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.vo.Auction_infoVO;
import com.javassem.vo.AuctioninfoVO;

@Repository
public class Auction_infoDAOImpl implements Auction_infoDAO{

	@Autowired
	private SqlSessionTemplate mybatis;
	
	@Override
	public List<Auction_infoVO> selectByC(Auction_infoVO vo) {
		System.out.println("selectByC 작업");
		return mybatis.selectList("auction_info.selectByC", vo);
	}

	@Override
	public Auction_infoVO selectByA(Auction_infoVO vo) {
		System.out.println("selectByA 작업");
		Auction_infoVO result = mybatis.selectOne("auction_info.selectByA", vo);
		System.out.println(result.toString());
		return result;
	}
	
	@Override
	public List<AuctioninfoVO> searchItem(AuctioninfoVO vo) {
		System.out.println("===> Mybatis.searchItem() 호출");
		return mybatis.selectList("member.searchItem", vo);
	}

}
