$(function(){

  // 000단위 , 구분
  function addComma(value){
        value = value.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return value; 
    }
   
  // 반복할 객체
  var size = $("#productSize").text();
  
  // 현재 날
  var date = new Date();
  var NOW = date.getTime();
  
  for(i = 0 ;i < size; i++){ 
  	var count = i + 1;  	
  	
  	var START_COST = $('#auction_'+count+'_START_COST').val();
  	if(	$('#auction_'+count).text() < START_COST){
  	$('#auction_'+count).text('시작가 : '+addComma(START_COST)+ '원');
  	}
  	/*
  	var START = $('#auction_'+count+'_START').val();
  	
  	var END = $('#auction_'+count+'_END').val();
  	
  	
  	
  	var stD = START-NOW;
  	var enD = NOW-END;
  	
  	if (stD > 259200000){
  	if (enD > 259200000){
  	$('#product'+i).hide();
  	}
  	}else { $('#product'+i).hide(); }
  	*/
	}
	
	
	/*
	// 분류 작업 내용 조건 내용 확인 (취소)
	$("#highAccess").click(function (){
		var size = $("#productSize").text();
		
		for(i = 0 ;i < size; i++){
			var count = i + 1;
			
		}
	});
	
	$("#closeEnd").click(function (){
		var size = $("#productSize").text();
		for(i = 0 ;i <  size; i++){
		
		}
	});
	
	$("#highCost").click(function (){
		var size = $("#productSize").text();
		for(i = 0 ;i <  size; i++){
		
		}
	});
	
	$("#lowCost").click(function (){
		var size = $("#productSize").text();
		for(i = 0 ;i <  size; i++){
		
		}
	});
	
	$("#highIng").click(function (){
		var size = $("#productSize").text();
		for(i = 0 ;i <  size; i++){
		
		}
	});
	
	$("#lowIng").click(function (){
		var size = $("#productSize").text();
		for(i = 0 ;i <  size; i++){
		
		}
	});
	
	$("#newId").click(function (){
		var size = $("#productSize").text();
		for(i = 0 ;i <  size; i++){
		
		}
	});
*/	

	// 페이지 4X2나누기
  var rowPerPage = 8;
    console.log(rowPerPage);
    
  $('#nav').remove();
  
  var  $products = $('#productList');

  $products.after('<div id="nav">');
  
  var $tr = $($products).find(' > div');
  var rowTotals = $tr.length;
	console.log(rowTotals);

  var pageTotal = Math.ceil(rowTotals/ rowPerPage);
  
  var i = 0;

  for (; i < pageTotal; i++) {
    
    $('<a href="#"></a>')
        .attr('rel', i)
        .html(i + 1)
        .appendTo('#nav');
        
  }

  $tr.addClass('off-screen')
      .slice(0, rowPerPage)
      .removeClass('off-screen');

  var $pagingLink = $('#nav a');
  
  $pagingLink.on('click', function (evt) {
    evt.preventDefault();
    var $this = $(this);
    if ($this.hasClass('active')) {
      return;
    }
    
    $pagingLink.removeClass('active');
    
    $this.addClass('active');

    // 0 => 0(0*4), 4(0*4+4)
    // 1 => 4(1*4), 8(1*4+4)
    // 2 => 8(2*4), 12(2*4+4)
    // 시작 행 = 페이지 번호 * 페이지당 행수
    // 끝 행 = 시작 행 + 페이지당 행수

    var currPage = $this.attr('rel');
    var startItem = currPage * rowPerPage;
    var endItem = startItem + rowPerPage;

    $tr.css('opacity', '0.0')
        .addClass('off-screen')
        .slice(startItem, endItem)
        .removeClass('off-screen')
        .animate({opacity: 1}, 300);

  });
 
  $pagingLink.filter(':first').addClass('active');


});